<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| SEO Setting Rules
|--------------------------------------------------------------------------
*/

$config['forminfo'] =load_config_yaml("forminfo.yaml");

/* End of file config.php */
/* Location: ./application/config/config.php */