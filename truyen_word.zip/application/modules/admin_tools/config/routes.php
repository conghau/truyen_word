<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
$route ['admin_tools/getconfig'] = 'manager/getConfig';
$route ['admin_tools/get_stories_full'] = 'manager/get_stories_full';