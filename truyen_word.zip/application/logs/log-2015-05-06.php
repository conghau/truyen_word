ERROR - 2015-05-06 07:39:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '? = 'CP00000000024'' at line 1 - Invalid query: 			select * from tbl_coupon where ? = 'CP00000000024'
ERROR - 2015-05-06 07:46:47 --> Query error: Table 'order.mytable' doesn't exist - Invalid query: SELECT *
FROM `mytable`
WHERE `code` = 'CP00000000024'
ERROR - 2015-05-06 07:47:55 --> Query error: Unknown column '?' in 'where clause' - Invalid query: 			select * from tbl_coupon where `?` = 'CP00000000024'
ERROR - 2015-05-06 07:48:10 --> Query error: Unknown column ' ? ' in 'where clause' - Invalid query: 			select * from tbl_coupon where ` ? ` = 'CP00000000024'
ERROR - 2015-05-06 08:17:42 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\TRUONG_CONG_HAU\application\controllers\Cart.php 138
ERROR - 2015-05-06 08:18:07 --> Severity: Notice --> Undefined index: has_product_in_cart D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 80
ERROR - 2015-05-06 08:18:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 80
ERROR - 2015-05-06 08:25:03 --> Severity: Notice --> Undefined index: msg_error_check_coupon D:\xampp\htdocs\TRUONG_CONG_HAU\application\controllers\Cart.php 132
ERROR - 2015-05-06 08:25:12 --> Severity: Notice --> Undefined index: msg_error_check_coupon D:\xampp\htdocs\TRUONG_CONG_HAU\application\controllers\Cart.php 132
ERROR - 2015-05-06 08:26:16 --> Severity: Notice --> Undefined index: msg_error_check_coupon D:\xampp\htdocs\TRUONG_CONG_HAU\application\controllers\Cart.php 132
ERROR - 2015-05-06 08:27:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''tbl_product
WHERE code' = 'qwqqw'
 LIMIT 1' at line 2 - Invalid query: SELECT *
FROM 'tbl_product
WHERE code' = 'qwqqw'
 LIMIT 1
ERROR - 2015-05-06 08:27:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"tbl_product
WHERE `code"` = 'wewewe'
 LIMIT 1' at line 2 - Invalid query: SELECT *
FROM "tbl_product
WHERE `code"` = 'wewewe'
 LIMIT 1
ERROR - 2015-05-06 08:29:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"tbl_product
WHERE `code"` = 'CP00000000024'
 LIMIT 1' at line 2 - Invalid query: SELECT *
FROM "tbl_product
WHERE `code"` = 'CP00000000024'
 LIMIT 1
ERROR - 2015-05-06 13:45:50 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:45:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:46:06 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:46:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:46:55 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:46:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:48:05 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:48:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:49:18 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:49:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:49:25 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:49:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:49:48 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:49:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:51:10 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:51:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:51:30 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:51:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:51:37 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:51:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:52:49 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:52:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:52:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Common.php 569
ERROR - 2015-05-06 13:52:50 --> Severity: Compile Error --> Cannot redeclare MY_Form_validation_test::test_check_is_exist_ShouldReturnTRUEWhenCouponExist() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\My_fom_vatidation_test.php 97
ERROR - 2015-05-06 13:52:53 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:52:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:52:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Common.php 569
ERROR - 2015-05-06 13:52:53 --> Severity: Compile Error --> Cannot redeclare MY_Form_validation_test::test_check_is_exist_ShouldReturnTRUEWhenCouponExist() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\My_fom_vatidation_test.php 97
ERROR - 2015-05-06 13:53:12 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:53:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:53:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Common.php 569
ERROR - 2015-05-06 13:53:12 --> Severity: Compile Error --> Cannot redeclare MY_Form_validation_test::test_check_is_exist_ShouldReturnTRUEWhenCouponExist() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\My_fom_vatidation_test.php 97
ERROR - 2015-05-06 13:54:25 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:54:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:54:46 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:54:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 13:54:59 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 13:54:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:09:13 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:09:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:09:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Userdao_test.php 84
ERROR - 2015-05-06 14:09:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Userdao_test.php 85
ERROR - 2015-05-06 14:10:10 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:10:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:10:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Userdao_test.php 84
ERROR - 2015-05-06 14:10:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Userdao_test.php 85
ERROR - 2015-05-06 14:10:10 --> Severity: Notice --> Undefined variable: binds D:\xampp\htdocs\TRUONG_CONG_HAU\application\models\userdao.php 64
ERROR - 2015-05-06 14:10:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?' at line 1 - Invalid query: SELECT * FROM tbl_user WHERE user_name = ?
ERROR - 2015-05-06 14:10:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Common.php 569
ERROR - 2015-05-06 14:11:03 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:11:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Userdao_test.php 84
ERROR - 2015-05-06 14:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Userdao_test.php 85
ERROR - 2015-05-06 14:11:32 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:11:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:11:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Userdao_test.php 84
ERROR - 2015-05-06 14:11:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Userdao_test.php 85
ERROR - 2015-05-06 14:11:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\models\userdao.php 65
ERROR - 2015-05-06 14:12:43 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:12:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:12:43 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:12:43 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:12:43 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:12:43 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 48
ERROR - 2015-05-06 14:12:43 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:12:43 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 58
ERROR - 2015-05-06 14:12:43 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 62
ERROR - 2015-05-06 14:12:43 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:12:43 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:12:43 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:12:43 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:13:27 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:13:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:13:27 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:13:27 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:13:27 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:13:27 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 48
ERROR - 2015-05-06 14:13:27 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:13:27 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 58
ERROR - 2015-05-06 14:13:27 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 62
ERROR - 2015-05-06 14:13:27 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:13:27 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:13:27 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 14:13:27 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 09:19:04 --> 404 Page Not Found: Oder/store_oder
ERROR - 2015-05-06 09:19:09 --> 404 Page Not Found: Order/store_oder
ERROR - 2015-05-06 09:28:07 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$id D:\xampp\htdocs\TRUONG_CONG_HAU\application\models\MY_Model.php 130
ERROR - 2015-05-06 09:48:23 --> Severity: Error --> Call to undefined method CI_Loader::mode() D:\xampp\htdocs\TRUONG_CONG_HAU\application\controllers\Order.php 56
ERROR - 2015-05-06 14:52:23 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:52:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:52:23 --> Severity: Notice --> Use of undefined constant CP00000000024 - assumed 'CP00000000024' D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Coupondao_test.php 28
ERROR - 2015-05-06 14:52:48 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:52:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:52:48 --> Severity: Notice --> Use of undefined constant CP00000000024 - assumed 'CP00000000024' D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Coupondao_test.php 28
ERROR - 2015-05-06 14:52:48 --> Severity: Notice --> Use of undefined constant CP00000000024 - assumed 'CP00000000024' D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Coupondao_test.php 38
ERROR - 2015-05-06 14:53:33 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:53:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:53:38 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:53:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:54:14 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:54:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:58:08 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:58:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:58:14 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:58:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:58:32 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:58:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:58:32 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Coupon_typedao_test.php 36
ERROR - 2015-05-06 14:58:37 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:58:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:58:53 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 14:58:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 14:58:53 --> Severity: Notice --> Use of undefined constant ABC - assumed 'ABC' D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\models\Coupon_typedao_test.php 46
ERROR - 2015-05-06 10:12:25 --> Severity: Notice --> Undefined index: address D:\xampp\htdocs\TRUONG_CONG_HAU\application\controllers\Order.php 35
ERROR - 2015-05-06 10:21:08 --> Severity: Notice --> Undefined index: address D:\xampp\htdocs\TRUONG_CONG_HAU\application\controllers\Order.php 35
ERROR - 2015-05-06 10:22:04 --> Severity: Notice --> Undefined index: address D:\xampp\htdocs\TRUONG_CONG_HAU\application\controllers\Order.php 35
ERROR - 2015-05-06 10:22:28 --> Severity: Notice --> Undefined index: address D:\xampp\htdocs\TRUONG_CONG_HAU\application\controllers\Order.php 35
ERROR - 2015-05-06 10:30:30 --> 404 Page Not Found: Card/detail
ERROR - 2015-05-06 10:30:35 --> 404 Page Not Found: Card/detail
ERROR - 2015-05-06 10:34:38 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 69
ERROR - 2015-05-06 10:34:38 --> Severity: Notice --> Undefined index: has_product_in_cart D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 80
ERROR - 2015-05-06 10:34:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 80
ERROR - 2015-05-06 10:34:38 --> Severity: Notice --> Undefined index: has_product_in_cart D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 222
ERROR - 2015-05-06 10:34:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 222
ERROR - 2015-05-06 10:40:27 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 69
ERROR - 2015-05-06 10:40:27 --> Severity: Notice --> Undefined index: has_product_in_cart D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 80
ERROR - 2015-05-06 10:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 80
ERROR - 2015-05-06 10:40:27 --> Severity: Notice --> Undefined index: has_product_in_cart D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 222
ERROR - 2015-05-06 10:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\7543350a5c92e6f9fd6c0e38025f14e18b426d95.file.cart_detail.tpl.php 222
ERROR - 2015-05-06 10:57:10 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\TRUONG_CONG_HAU\application\controllers\Cart.php 153
ERROR - 2015-05-06 11:29:27 --> Severity: Notice --> Undefined variable: arr_order_detail D:\xampp\htdocs\TRUONG_CONG_HAU\application\models\orderdao.php 38
ERROR - 2015-05-06 16:52:57 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 16:52:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 16:52:57 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\libraries\Cart_manager.php 16
ERROR - 2015-05-06 16:52:57 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\libraries\Cart_manager.php 16
ERROR - 2015-05-06 17:14:24 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:14:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:15:04 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:15:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:15:05 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\libraries\Cart_manager.php 16
ERROR - 2015-05-06 17:15:05 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\libraries\Cart_manager.php 16
ERROR - 2015-05-06 17:15:14 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:15:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:15:15 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:15:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:22:32 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:22:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:22:32 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:22:32 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:22:32 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:22:32 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 48
ERROR - 2015-05-06 17:22:32 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:22:32 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 58
ERROR - 2015-05-06 17:22:32 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 62
ERROR - 2015-05-06 17:22:32 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:22:32 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:22:32 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:22:32 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:23 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:23:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:23:24 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:24 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:24 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:24 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 48
ERROR - 2015-05-06 17:23:24 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:24 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 58
ERROR - 2015-05-06 17:23:24 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 62
ERROR - 2015-05-06 17:23:24 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:24 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:24 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:24 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:47 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:23:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:23:47 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:47 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:47 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:47 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 48
ERROR - 2015-05-06 17:23:47 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:47 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 58
ERROR - 2015-05-06 17:23:47 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 62
ERROR - 2015-05-06 17:23:47 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:47 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:47 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:23:47 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:24:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:24:35 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:24:35 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 48
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 58
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\libraries\Login_manager.php 57
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 62
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> Undefined index: sess_login D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 72
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:24:35 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:25:27 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:25:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:25:27 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:25:27 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:25:27 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:25:27 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 48
ERROR - 2015-05-06 17:25:27 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:25:27 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 58
ERROR - 2015-05-06 17:25:27 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 62
ERROR - 2015-05-06 17:25:27 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:25:27 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:25:27 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:25:27 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:25:27 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:25:27 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:27:41 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:27:41 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:27:41 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:27:41 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:27:41 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 48
ERROR - 2015-05-06 17:27:41 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:27:41 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 58
ERROR - 2015-05-06 17:27:41 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\libraries\Login_manager.php 56
ERROR - 2015-05-06 17:27:41 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 62
ERROR - 2015-05-06 17:27:41 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:27:41 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:27:41 --> Severity: Notice --> Undefined index: sess_login D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 72
ERROR - 2015-05-06 17:27:41 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:27:41 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:27:41 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:27:41 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:38:39 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:38:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:38:39 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:38:39 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:38:39 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:38:39 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 48
ERROR - 2015-05-06 17:38:39 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:38:39 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 58
ERROR - 2015-05-06 17:38:39 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\libraries\Login_manager.php 56
ERROR - 2015-05-06 17:38:39 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 62
ERROR - 2015-05-06 17:38:39 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:38:39 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:38:39 --> Severity: Notice --> Undefined index: sess_login D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 72
ERROR - 2015-05-06 17:38:39 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:38:39 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:38:39 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:38:39 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:55:54 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 208
ERROR - 2015-05-06 17:55:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Security.php 277
ERROR - 2015-05-06 17:55:54 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:55:54 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:55:54 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:55:54 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 48
ERROR - 2015-05-06 17:55:54 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:55:54 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 58
ERROR - 2015-05-06 17:55:54 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\libraries\Login_manager.php 56
ERROR - 2015-05-06 17:55:54 --> Severity: Notice --> Undefined variable: _SESSION D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 62
ERROR - 2015-05-06 17:55:54 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:55:54 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:55:54 --> Severity: Notice --> Undefined index: sess_login D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 72
ERROR - 2015-05-06 17:55:54 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:55:54 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at D:\xampp\htdocs\TRUONG_CONG_HAU\system\core\Exceptions.php:272) D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:55:54 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
ERROR - 2015-05-06 17:55:54 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\xampp\htdocs\TRUONG_CONG_HAU\application\tests\libraries\Login_manager_test.php 28
