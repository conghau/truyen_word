<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-05-11 03:33:55 --> 404 Page Not Found: Logi/index
ERROR - 2015-05-11 03:47:39 --> 404 Page Not Found: /index
ERROR - 2015-05-11 03:49:25 --> 404 Page Not Found: /index
ERROR - 2015-05-11 03:51:58 --> 404 Page Not Found: /index
ERROR - 2015-05-11 03:52:00 --> 404 Page Not Found: /index
ERROR - 2015-05-11 03:52:01 --> 404 Page Not Found: /index
ERROR - 2015-05-11 03:52:01 --> 404 Page Not Found: /index
ERROR - 2015-05-11 03:52:01 --> 404 Page Not Found: /index
ERROR - 2015-05-11 04:15:58 --> 404 Page Not Found: /index
ERROR - 2015-05-11 04:22:32 --> Severity: Error --> Call to undefined function validation_errors() D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\c353340986e7d956f811b91d8946f304ee2c9ed7.file.login1.tpl.php 68
ERROR - 2015-05-11 04:23:03 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\TRUONG_CONG_HAU\application\modules\test\views\login1.tpl"  on line 35 "<h3>{validation_errors('<div class="alert alert-error">', '</div>')}</h3>" unknown function "validation_errors" D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 35
ERROR - 2015-05-11 04:23:09 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\TRUONG_CONG_HAU\application\modules\test\views\login1.tpl"  on line 35 "<h3>{validation_errors('<div class="alert alert-error">', '</div>')}</h3>" unknown function "validation_errors" D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 35
ERROR - 2015-05-11 04:23:10 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\TRUONG_CONG_HAU\application\modules\test\views\login1.tpl"  on line 35 "<h3>{validation_errors('<div class="alert alert-error">', '</div>')}</h3>" unknown function "validation_errors" D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 35
ERROR - 2015-05-11 04:23:11 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\TRUONG_CONG_HAU\application\modules\test\views\login1.tpl"  on line 35 "<h3>{validation_errors('<div class="alert alert-error">', '</div>')}</h3>" unknown function "validation_errors" D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 35
ERROR - 2015-05-11 04:24:06 --> Severity: Error --> Call to undefined function validation_errors() D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\c353340986e7d956f811b91d8946f304ee2c9ed7.file.login1.tpl.php 68
ERROR - 2015-05-11 04:38:20 --> Severity: Error --> Cannot access protected property MY_Form_validation::$CI D:\xampp\htdocs\TRUONG_CONG_HAU\application\modules\test\controllers\test.php 9
ERROR - 2015-05-11 04:38:43 --> Severity: Error --> Cannot access protected property MY_Form_validation::$CI D:\xampp\htdocs\TRUONG_CONG_HAU\application\modules\test\controllers\test.php 9
ERROR - 2015-05-11 06:17:30 --> 404 Page Not Found: /index
ERROR - 2015-05-11 06:18:19 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\TRUONG_CONG_HAU\application\views\layout\master.tpl"  on line 81 "</div> <script type="text/javascript">var addthis_config = {"data_track_addressbar":false};</script>"  - Unexpected ":", expected one of: "}" D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 81
ERROR - 2015-05-11 06:18:23 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\TRUONG_CONG_HAU\application\views\layout\master.tpl"  on line 81 "</div> <script type="text/javascript">var addthis_config = {"data_track_addressbar":false};</script>"  - Unexpected ":", expected one of: "}" D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 81
ERROR - 2015-05-11 06:19:45 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\TRUONG_CONG_HAU\application\views\layout\master.tpl"  on line 81 "</div> <script type="text/javascript">//var addthis_config = {"data_track_addressbar":false};</script>"  - Unexpected ":", expected one of: "}" D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 81
ERROR - 2015-05-11 06:20:01 --> Severity: Notice --> Undefined index: user_logined D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(157) : eval()'d code 158
ERROR - 2015-05-11 06:20:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(157) : eval()'d code 158
ERROR - 2015-05-11 06:20:52 --> Severity: Notice --> Undefined index: user_logined D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\823e4c159e314241f32e55e546778d41efff2dae.file.login1.tpl.php 158
ERROR - 2015-05-11 06:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\templates_c\823e4c159e314241f32e55e546778d41efff2dae.file.login1.tpl.php 158
ERROR - 2015-05-11 06:22:15 --> Severity: Notice --> Undefined index: user_logined D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 155
ERROR - 2015-05-11 06:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 155
ERROR - 2015-05-11 07:01:48 --> Severity: Notice --> Undefined index: user_logined D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 146
ERROR - 2015-05-11 07:01:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 146
ERROR - 2015-05-11 08:02:58 --> Severity: Notice --> Undefined index: user_logined D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 161
ERROR - 2015-05-11 08:02:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\TRUONG_CONG_HAU\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 161
ERROR - 2015-05-11 08:02:58 --> 404 Page Not Found: /index
ERROR - 2015-05-11 10:58:25 --> 404 Page Not Found: /index
ERROR - 2015-05-11 10:58:25 --> 404 Page Not Found: /index
ERROR - 2015-05-11 10:58:25 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:02:39 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:02:39 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:05:24 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:12:44 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:12:44 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:12:44 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:12:44 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:16:55 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:16:55 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:16:55 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:19:53 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:19:53 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:21:48 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:21:48 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:21:48 --> 404 Page Not Found: /index
ERROR - 2015-05-11 11:21:48 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:31:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'order' D:\xampp\htdocs\truyen_word\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2015-05-11 15:31:44 --> Unable to connect to the database
ERROR - 2015-05-11 15:31:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'order' D:\xampp\htdocs\truyen_word\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2015-05-11 15:31:50 --> Unable to connect to the database
ERROR - 2015-05-11 15:33:10 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:33:10 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:33:10 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:33:10 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:33:10 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:33:10 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:44:07 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:44:32 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:44:38 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:44:46 --> 404 Page Not Found: ../modules/stories/controllers//index
ERROR - 2015-05-11 15:45:27 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:45:27 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:46:13 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:46:13 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:47:22 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:47:22 --> 404 Page Not Found: /index
ERROR - 2015-05-11 15:47:59 --> 404 Page Not Found: ../modules/stories/controllers/Stories/details
ERROR - 2015-05-11 15:48:07 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\detail.tpl"  on line 240 "</div> <script type="text/javascript">var addthis_config = {"data_track_addressbar":false};</script>"  - Unexpected ":", expected one of: "}" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 237
ERROR - 2015-05-11 15:48:47 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\detail.tpl"  on line 855 "FB.init({appId: '436858599773584', status: true, cookie: true, xfbml: true});"  - Unexpected ": ", expected one of: "}" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 852
ERROR - 2015-05-11 15:50:16 --> 404 Page Not Found: ../modules/stories/controllers/Stories/public
ERROR - 2015-05-11 15:50:16 --> 404 Page Not Found: ../modules/stories/controllers/Stories/public
ERROR - 2015-05-11 15:50:16 --> 404 Page Not Found: ../modules/stories/controllers/Stories/public
ERROR - 2015-05-11 15:55:31 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\chapter.tpl"  on line 178 "FB.init({appId: '436858599773584', status: true, cookie: true, xfbml: true});"  - Unexpected ": ", expected one of: "}" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 175
ERROR - 2015-05-11 15:56:03 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\chapter.tpl"  on line 181 ".fb_iframe_widget iframe[style]  {width: 100% !important;}</style>"  - Unexpected ": ", expected one of: "}" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 178
ERROR - 2015-05-11 15:56:23 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\chapter.tpl"  on line 751 "var test = $('#report_success').slideDown('fast').delay(1000).slideUp('fast', function(){$('#modal_truyen_report').modal('hide');});"  - Unexpected "(", expected one of: "{" , "identifier" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 748
ERROR - 2015-05-11 15:57:50 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\chapter.tpl"  on line 752 "var test = $('#report_success').slideDown('fast').delay(1000).slideUp('fast', function(){$('#modal_truyen_report').modal('hide');});"  - Unexpected "(", expected one of: "{" , "identifier" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 99
ERROR - 2015-05-11 15:57:52 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\chapter.tpl"  on line 752 "var test = $('#report_success').slideDown('fast').delay(1000).slideUp('fast', function(){$('#modal_truyen_report').modal('hide');});"  - Unexpected "(", expected one of: "{" , "identifier" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 99
ERROR - 2015-05-11 15:59:00 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\chapter.tpl"  on line 709 "var test = $('#report_success').slideDown('fast').delay(1000).slideUp('fast', function(){$('#modal_truyen_report').modal('hide');});"  - Unexpected "(", expected one of: "{" , "identifier" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 99
ERROR - 2015-05-11 15:59:05 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\chapter.tpl"  on line 709 "var test = $('#report_success').slideDown('fast').delay(1000).slideUp('fast', function(){$('#modal_truyen_report').modal('hide');});"  - Unexpected "(", expected one of: "{" , "identifier" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 99
ERROR - 2015-05-11 15:59:05 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\chapter.tpl"  on line 709 "var test = $('#report_success').slideDown('fast').delay(1000).slideUp('fast', function(){$('#modal_truyen_report').modal('hide');});"  - Unexpected "(", expected one of: "{" , "identifier" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 99
ERROR - 2015-05-11 15:59:59 --> 404 Page Not Found: ../modules/stories/controllers/Stories/public
ERROR - 2015-05-11 15:59:59 --> 404 Page Not Found: ../modules/stories/controllers/Stories/public
ERROR - 2015-05-11 15:59:59 --> 404 Page Not Found: ../modules/stories/controllers/Stories/public
