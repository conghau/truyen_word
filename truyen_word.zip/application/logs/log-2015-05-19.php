<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-05-19 06:30:00 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 240
ERROR - 2015-05-19 06:30:01 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 240
ERROR - 2015-05-19 06:30:01 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 240
ERROR - 2015-05-19 06:30:01 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 240
ERROR - 2015-05-19 06:30:02 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 240
ERROR - 2015-05-19 06:30:02 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 240
ERROR - 2015-05-19 06:30:03 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 240
ERROR - 2015-05-19 06:30:03 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 240
ERROR - 2015-05-19 06:30:04 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 240
ERROR - 2015-05-19 06:30:04 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 240
ERROR - 2015-05-19 06:30:42 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 241
ERROR - 2015-05-19 06:30:42 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 241
ERROR - 2015-05-19 06:30:42 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 241
ERROR - 2015-05-19 06:30:43 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 241
ERROR - 2015-05-19 06:30:43 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 241
ERROR - 2015-05-19 06:30:43 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 241
ERROR - 2015-05-19 06:30:43 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 241
ERROR - 2015-05-19 06:30:44 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 241
ERROR - 2015-05-19 06:30:44 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 241
ERROR - 2015-05-19 06:30:44 --> Severity: Notice --> Undefined property: stdClass::$crawler_update D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 241
ERROR - 2015-05-19 06:47:45 --> Query error: Unknown column 'type' in 'field list' - Invalid query: UPDATE `tbl_stories` SET `author` = CASE 
WHEN `id` = '107' THEN 'Vụ Ngoại Giang Sơn'
WHEN `id` = '108' THEN 'Cóc Lang Thang'
WHEN `id` = '109' THEN 'Thụy Thu'
WHEN `id` = '110' THEN 'Hạ Nhật Dịch Lãnh'
WHEN `id` = '111' THEN 'Deviltrigger'
WHEN `id` = '112' THEN 'Hoàng Kim Hải Ngạn'
WHEN `id` = '113' THEN 'Quan Kỳ'
WHEN `id` = '114' THEN 'Tâm Mộng Vô Ngân'
WHEN `id` = '115' THEN 'Trạch Trư'
WHEN `id` = '116' THEN 'Mặc Thủy'
ELSE `author` END, `type` = CASE 
WHEN `id` = '107' THEN 'Tiên hiệp'
WHEN `id` = '108' THEN 'Tiên hiệp'
WHEN `id` = '109' THEN 'Tiên hiệp'
WHEN `id` = '110' THEN 'Tiên hiệp'
WHEN `id` = '111' THEN 'Tiên hiệp'
WHEN `id` = '112' THEN 'Tiên hiệp'
WHEN `id` = '113' THEN 'Tiên hiệp , Quân sự'
WHEN `id` = '114' THEN 'Tiên hiệp'
WHEN `id` = '115' THEN 'Tiên hiệp'
WHEN `id` = '116' THEN 'Tiên hiệp'
ELSE `type` END, `source` = CASE 
WHEN `id` = '107' THEN 'tangthuvien.vn'
WHEN `id` = '108' THEN 'Vipvandan.vn'
WHEN `id` = '109' THEN 'Sưu tầm'
WHEN `id` = '110' THEN 'vipvandan'
WHEN `id` = '111' THEN 'tangthuvien'
WHEN `id` = '112' THEN 'vipvandan'
WHEN `id` = '113' THEN 'vipvandan'
WHEN `id` = '114' THEN 'Sưu tầm'
WHEN `id` = '115' THEN 'tangthuvien, vipvandan'
WHEN `id` = '116' THEN 'vipvandan'
ELSE `source` END, `state` = CASE 
WHEN `id` = '107' THEN 'Đang cập nhật'
WHEN `id` = '108' THEN 'Đang cập nhật'
WHEN `id` = '109' THEN 'Đang cập nhật'
WHEN `id` = '110' THEN 'Đang cập nhật'
WHEN `id` = '111' THEN 'Đang cập nhật'
WHEN `id` = '112' THEN 'Đang cập nhật'
WHEN `id` = '113' THEN 'Đang cập nhật'
WHEN `id` = '114' THEN 'Đang cập nhật'
WHEN `id` = '115' THEN 'Đang cập nhật'
WHEN `id` = '116' THEN 'Đang cập nhật'
ELSE `state` END, `view` = CASE 
WHEN `id` = '107' THEN '39479'
WHEN `id` = '108' THEN '54726'
WHEN `id` = '109' THEN '68872'
WHEN `id` = '110' THEN '132275'
WHEN `id` = '111' THEN '10277'
WHEN `id` = '112' THEN '4133'
WHEN `id` = '113' THEN '262714'
WHEN `id` = '114' THEN '58220'
WHEN `id` = '115' THEN '302348'
WHEN `id` = '116' THEN '7903'
ELSE `view` END, `rating` = CASE 
WHEN `id` = '107' THEN '9.21  out of 10'
WHEN `id` = '108' THEN '8.21  out of 10'
WHEN `id` = '109' THEN '9.30  out of 10'
WHEN `id` = '110' THEN '9.31  out of 10'
WHEN `id` = '111' THEN '8.64  out of 10'
WHEN `id` = '112' THEN '9.90  out of 10'
WHEN `id` = '113' THEN '9.31  out of 10'
WHEN `id` = '114' THEN '8.07  out of 10'
WHEN `id` = '115' THEN '8.65  out of 10'
WHEN `id` = '116' THEN '9.78  out of 10'
ELSE `rating` END, `source_id` = CASE 
WHEN `id` = '107' THEN '3702'
WHEN `id` = '108' THEN '3746'
WHEN `id` = '109' THEN '2688'
WHEN `id` = '110' THEN '6128'
WHEN `id` = '111' THEN '6421'
WHEN `id` = '112' THEN '6185'
WHEN `id` = '113' THEN '44'
WHEN `id` = '114' THEN '3247'
WHEN `id` = '115' THEN '2749'
WHEN `id` = '116' THEN '6442'
ELSE `source_id` END, `intro` = CASE 
WHEN `id` = '107' THEN 'Đọc truyện <a href=\"http://webtruyen.com/dai-dao-doc-hanh/\">Đại Đạo Độc Hành</a> của tác giả Vu Ngoại Giang Sơn là một truyện khá đặc sắc, cũng là câu chuyện võ hiệp nhưng tác phẩm thực sự để lại ấn tượng cho người đọc bởi lối viết văn và nội dụng truyện. Nhiều khi đọc truyện ta cảm nhận được mình đang thực sự chu du vào thế giới <a href=\"http://webtruyen.com/tien-hiep/\">truyện tiên hiệp</a> đầy màu sắc kì ảo này.<br/><br/><a href=\"http://webtruyen.com/\">Truyện</a> là hành trình tu tiên, hành trình trên một không gian khác lạ, con đường đi qua không dài nhưng cũng chẳng ngắn, để đi được chặng đường này, cần nhất là sự kiên trì, là tâm căn muốn theo đuổi sự nghiệp võ học.<br/><br/>Ba nghìn Tả đạo, tám trăm bàng môn, thượng môn một trăm lẻ tám, ở nơi này tu giả nhiều như kiến thời đại.<br/><br/>Tu giả hướng đến tay cầm ngũ hành, chân đạp âm dương, siêu thoát sinh tử luân hồi, theo đuổi vĩnh hằng đại đạo.<br/><br/>Khổ tu, du lịch, ngộ đạo, tử chiến, trải qua vạn kiếp, giữ vững lòng tin, cuối cùng sẽ đi đến đỉnh cao, vừa xem cửu thiên mịt mù.<br/><br/>Ta rốt cuộc đứng tại đỉnh cửu thiên, mới phát hiện cần cù cầu đại đạo, chẳng qua đường ta đã đi, đường này chỉ mới bắt đầu!<br/><br/>Đạo trời mênh mông, chỉ mình ta đi!<br/><br/> '
WHEN `id` = '108' THEN 'Một tuyệt phẩm <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> mới của tác giả Cóc Lang Thang nay được dịch và giới thiệu đến bạn đọc truyện Phần Thiên. Nội dung <a href=\"http://webtruyen.com/phan-thien/\">truyện phần thiên</a> không phải là câu truyện nói về người quân tử, mà là câu truyện nói về một kẻ vô sỉ, cực kỳ vô sỉ. Có tiền tài cứ lấy, có gái theo cứ nhận, có việc gì phải băn khoăn? Thường thì anh hùng chết trước, tiểu nhân sống dai đúng không? Vậy thì ta sẽ là một kẻ tiểu nhân.<br/><br/>Lời dịch giả : Đây là truyện đầu tiên mình ra riêng sau khi rất nhiều lần bị đồng đội bỏ bom, mình xin phép được dịch thể loại mà mình yêu thích, thể loại vô sỉ, rất mong mọi người ủng hộ. Xin cảm ơn. '
WHEN `id` = '109' THEN 'Bạn đang đọc truyện Chân Linh Cửu Biến của tác giả Thụy Thu trên trang đọc truyện online.<br>Truyện kể về quá trình một tu sĩ phổ thông phấn đấu tu luyện, trưởng thành, bao gồm cả quá trình phát triển của một môn phái với bao quyền mưu, ám sát, chiến đấu, lợi ích và phấn đấu.<br><br>&nbsp;Đó là một tràng nhân yêu hai tộc đối kháng, rồi đại kiếp đến gần, để các bên hợp tung liên hoành tranh đấu cho sự tồn tại. <br><br>Trong truyện, tu sĩ Lục Bình đệ tử của Chân Linh phái chuyên tu thủy hệ công pháp những bằng nổ lực của mình đã từng bước thành công về luyện phù, luyện đan, tu thành thần thông giành lấy tiếng nói cho chính mình, chống lại những âm mưu đã ẩn giấu thâm sâu trong tu chân giới hàng vạn năm. '
WHEN `id` = '110' THEN 'So với <a href=\"http://webtruyen.com/chan-linh-cuu-bien/\">Châu Linh Cửu Biến</a> và <a href=\"http://webtruyen.com/dai-dao-doc-hanh/\">Đại Đạo Độc Hành</a> thì <a href=\"http://webtruyen.com/trieu-hoan-than-binh/\">Triệu Hoán Thần Binh</a> được đánh giá là tác phẩm có lối dẫn <a href=\"http://webtruyen.com/\">truyện hay</a>, khiến nhiều bạn đọc say mê với lối hành văn tinh tế của Hạ Nhật Dịch Lãnh.<br/><br/>*** <br/><br/>Nam nhân cầm thanh loan đao nhìn trường thương bị hủy ở trên tay hắn rơi xuống, khí tức anh hùng lập tức chấn động, lại xông qua chém giết.<br/><br/>Vu Nhai cảm thấy bất đắc dĩ.<br/><br/>Thế giới chết tiệt này, không có Huyền Binh bản mạng nhập thể chính là thấp hơn người một phần. Kẻ nắm giữ Huyền Binh chính là quý tộc. Huyền khí trong tay bọn họ, trăm phần trăm truyền chính là Huyền Binh huyền khí bản mạng nhập thể. Trừ khi chất liệu vũ khí của ngươi vô cùng tốt, còn không, gần như chỉ vừa va chạm sẽ lập tức vỡ nát. Hắn chỉ là một tiểu binh thủ thành nho nhỏ, có thể được phân phối vũ khí chất liệu tốt sao? Nói thừa!<br/><br/>Nhìn thấy thanh loan đao kia đâm tới, từ huyền khí phía trên thanh loan đao có thể phán đoán được, người này hẳn là cao hơn so với mình mấy đẳng cấp. Hắn lại có Huyền Binh, hẳn là bối cảnh không nhỏ. Chất lượng Huyền Binh của hắn chí ít phải đạt được tam giai. Vậy phải làm sao?<br/><br/>*** <br/><br/>Mời bạn đọc khám phá về thế giới <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> với nhân vật Vu Nhai. So với những vị anh hùng quả cảm thì Vu Nhai quả thực là nhân vật tài sắc vẹn toàn, dù không hơn thắng thua nhưng những kẻ tiểu nhân vẫn khiến các anh hùng phải ái ngại.<br/><br/> '
WHEN `id` = '111' THEN 'So với những tác phẩm cùng loại khác thì <a href=\"http://webtruyen.com/truyen-moi-dang/\">truyện mới</a> <a href=\"http://webtruyen.com/trong-sinh-tai-nhan-gioi/\">Trọng Sinh Tại Nhẫn Giới</a> mang đến cho bạn đọc những yếu tố huyền huyễn và mờ ảo đầy ly kì.<br/><br/>*** <br/><br/>Mặt trăng tròn vằng vặc chiếu lên trên một ngôi làng... Trong một căn nhà gỗ, tiếng gào thét của một vị nữ nhân liên tục phát ra: “A, a, a... đau quá!”<br/><br/>Một vị nữ tính khác phát ra âm thanh: “Cố lên phu nhân, sắp ra rồi! Sắp ra rồi!”<br/><br/>Một người thanh niên đi đi lại lại ở phía cảnh cửa. Hắn nhìn về phía sau đám cánh cửa được thiết kế bằng gỗ. Những tấm dán bằng giấy cổ điện và trang nhã được phủ lên trên đó. Thông qua ánh sáng ở bên trong hiện lên những bóng người. Người thanh niên khoảng hơn hai mươi tuổi này liên tục đi đi lại lại, bộ dạng vô cùng khẩn trương và lo lắng.<br/><br/>Vị thanh niên này có mái tóc màu đen xám, con mắt khá to, hàng lông mày dày rậm và hơi cong. Sống mũi khá cao thể hiện sự ương ngạnh cùng với một cái trán rô bóng loáng. Hai hàng tóc được chải sang hai bên. Trên khuôn mặt thể hiện sự cao ngạo và tự tin. Bộ dạng của hắn khá là đẹp trai. Tuy nhiên bộ dạng của hắn lúc này thì vô cùng lo lắng.<br/><br/>*** <br/><br/>Liên tiếp những tình tiết gay cấn và hấp dẫn sẽ có trong truyện <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a>, mời bạn đọc khám phá. <br/><br/> '
WHEN `id` = '112' THEN 'Truyện <a href=\"http://webtruyen.com/tro-choi-tu-vong-luan-hoi/\">Trò Chơi Tử Vong Luân Hồi</a> sẽ đưa chúng ta đến những năng lực trong trò chơi mà có thể sẽ áp dụng năng lực đó ra ngoài đời thực. Khi áp dụng những kỹ năng ra đời thực cũng là điều không hề dễ dàng...<br/><br/>Người bạn của Tô Bằng chết ẩn mà khiến hắn đến với một trò chơi kỳ lạ. Công ty thần bí kỳ lạ, đồng nghiệp che giấu bí mật, cái chết kỳ lạ của đồng nghiệp...Tất cả đều khiến cho Tô Bằng cuốn vào trong vòng xoáy.<br/><br/>Gia tộc xua đuổi Tô Bằng bởi những âm mưu trùng trùng điệp điệp. Liệu Tô Bằng sẽ áp dụng kỹ năng trong trò chơi ấy ra sao? Sức mạnh đạt đến cỡ nào?<br/><br/>Với tác phẩm <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> đem lại những tình tiết bất ngờ và thú vị cho bạn đọc. Một trò chơi nguy hiểm xoay vòng dẫn dắt bạn đọc đến với một thế giới với sức mạnh cực đại.<br/><br/>Mời bạn đọc khám phá <a href=\"http://webtruyen.com/\">truyện online</a> và tìm kiếm câu trả lời. <br/><br/> '
WHEN `id` = '113' THEN 'Bạn đang đọc truyện Tiên Quốc Đại Đế của tác giả Quan Kỳ trên trang đọc truyện online. Thiên hạ to lớn, duy ta chính thống! Dùng Thiên triều xu thế quét ngang thiên hạ tiên môn! Một cái cường giả tu \'Đế vương chi Đạo\', hàng lâm thế giới Tiên môn san sát, làm cho một cái người tu hành hèn mọn thế tục Vương triều, từng bước một đi đến cùng các đại đỉnh cấp Tiên môn bình khởi bình tọa. Vương triều pháp tắc là, trong thiên hạ chẳng lẽ vương thổ, suất thổ tân chẳng lẽ vương thần! Thiên hạ chính thống chỉ có một, hết thảy tiên môn, đều là tổ chức phi pháp! '
WHEN `id` = '114' THEN 'Đọc thể loại <a href=\"http://webtruyen.com/huyen-huyen/\">truyện huyền huyễn</a> người đọc không thể không bị hấp dẫn vào thế giới hư ảo của câu chuyện.<br/><br/>Có chút thực có chút giả, ảo tưởng nhưng lại rất thật. Một không gian mênh mang. <br/><br/>Hoa thiên long bệnh hoạn, khuyết tật, một người sinh ra mẹ đã chết trải qua bao bi phẫn của cuộc đời.<br/><br/>Vốn cứ tưởng mọi thứ đều mong manh như vậy nhưng nào ngờ lại có tình yêu...<br/><br/>Anh hùng gởi thân ở chiến trường.<br/><br/>Còn ta gởi thân chốn Thiên Đường.<br/><br/>…<br/><br/>Võ có thể thông thần, ý có thể thông thiên.<br/><br/>Thần ma ngạo thế, chư thiên vô hạn.<br/><br/>Bát cực thần điện, hùng bá vạn năm.<br/><br/>Tam giới song song, nhân thần chi chiến.<br/><br/>Cùng đọc tác phẩm <a href=\"http://webtruyen.com/thien-thanh/\">Thiên Thánh</a> để có thể cảm nhận hết được tứ thơ này nhé !!! '
WHEN `id` = '115' THEN 'Ai là fan của tác giả Trạch Trư hay là đã từng mất ăn mất ngủ với bộ truyện <a href=\"http://webtruyen.com/doc-bo-thien-ha/\">độc bộ thiên hạ</a> thì không thể bỏ qua bộ truyện <a href=\"http://webtruyen.com/de-ton\">Đế Tôn</a> này nhé. Đế tôn là truyện thuộc thể loại tiên hiệp. Truyện mới ra mắt ngày 20-2-2013. Hy vọng sẽ làm hài lọng bạn đọc mê <a href=\"http://webtruyen.com\">truyện</a>.<br/><br/>Võ đạo có thể Thông Thần!<br/><br/>Võ đạo tu luyện đến Thần Luân cảnh giới, liền có thể luyện tựu Thần Thông, siêu phàm thoát tục!<br/><br/>tác giả tác phẩm:<br/><br/>[ tiên hiệp ] đế tôn<br/><br/>[ tiên hiệp ] độc bộ thiên hạ<br/><br/>[ tiên hiệp ] sống lại tây du<br/><br/>[ huyền huyễn ] dã man vương tọa<br/><br/>[ tiên hiệp ]Thủy hử tiên đồ '
WHEN `id` = '116' THEN 'Truyện <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> <a href=\"http://webtruyen.com/hop-the-song-tu/\">Hợp Thể Song Tu</a> còn gọi tên khác là Chấp Ma của tác giả Mặc Thủy! Cốt truyện ban đầu có một chút sắc hợp lý, thế giới rộng lớn, nhân vật chính không não tàn, gái gú dám yêu dám hận.<br/><br/>Nhân vật chính là Ninh Phàm bị bạn chí thân phản bội hãm hại, để rồi nhờ cơ duyên mà ngẫu nhiên lấy được song tu đế bảo, từ đó bước trên con đường tu ma thiên hạ vô địch. Linh trang, pháp bảo, đạo quả, tiên vân, thiên sương hàn khí, địa mạch yêu hỏa... xuất hiện liên tục.<br/><br/>Năng lực được khám phá đại đạo âm dương, lấy thiên làm thê, lấy địa làm thiếp , lấy thương sinh làm đỉnh lô. Âm dương đại đạo, hợp thể song tu! Sức mạnh chỉ có thể phát huy khi tất cả đều trong một!<br/><br/>Mời bạn đọc theo dõi <a href=\"http://webtruyen.com/\">truyện online</a>. <br/><br/> '
ELSE `intro` END, `number_page` = CASE 
WHEN `id` = '107' THEN '8'
WHEN `id` = '108' THEN '11'
WHEN `id` = '109' THEN '12'
WHEN `id` = '110' THEN '39'
WHEN `id` = '111' THEN '2'
WHEN `id` = '112' THEN '3'
WHEN `id` = '113' THEN '27'
WHEN `id` = '114' THEN '11'
WHEN `id` = '115' THEN '42'
WHEN `id` = '116' THEN '1'
ELSE `number_page` END
WHERE `id` IN('107','108','109','110','111','112','113','114','115','116')
ERROR - 2015-05-19 06:49:56 --> Query error: Unknown column 'source_id' in 'field list' - Invalid query: UPDATE `tbl_stories` SET `author` = CASE 
WHEN `id` = '107' THEN 'Vụ Ngoại Giang Sơn'
WHEN `id` = '108' THEN 'Cóc Lang Thang'
WHEN `id` = '109' THEN 'Thụy Thu'
WHEN `id` = '110' THEN 'Hạ Nhật Dịch Lãnh'
WHEN `id` = '111' THEN 'Deviltrigger'
WHEN `id` = '112' THEN 'Hoàng Kim Hải Ngạn'
WHEN `id` = '113' THEN 'Quan Kỳ'
WHEN `id` = '114' THEN 'Tâm Mộng Vô Ngân'
WHEN `id` = '115' THEN 'Trạch Trư'
WHEN `id` = '116' THEN 'Mặc Thủy'
ELSE `author` END, `type` = CASE 
WHEN `id` = '107' THEN 'Tiên hiệp'
WHEN `id` = '108' THEN 'Tiên hiệp'
WHEN `id` = '109' THEN 'Tiên hiệp'
WHEN `id` = '110' THEN 'Tiên hiệp'
WHEN `id` = '111' THEN 'Tiên hiệp'
WHEN `id` = '112' THEN 'Tiên hiệp'
WHEN `id` = '113' THEN 'Tiên hiệp , Quân sự'
WHEN `id` = '114' THEN 'Tiên hiệp'
WHEN `id` = '115' THEN 'Tiên hiệp'
WHEN `id` = '116' THEN 'Tiên hiệp'
ELSE `type` END, `source` = CASE 
WHEN `id` = '107' THEN 'tangthuvien.vn'
WHEN `id` = '108' THEN 'Vipvandan.vn'
WHEN `id` = '109' THEN 'Sưu tầm'
WHEN `id` = '110' THEN 'vipvandan'
WHEN `id` = '111' THEN 'tangthuvien'
WHEN `id` = '112' THEN 'vipvandan'
WHEN `id` = '113' THEN 'vipvandan'
WHEN `id` = '114' THEN 'Sưu tầm'
WHEN `id` = '115' THEN 'tangthuvien, vipvandan'
WHEN `id` = '116' THEN 'vipvandan'
ELSE `source` END, `state` = CASE 
WHEN `id` = '107' THEN 'Đang cập nhật'
WHEN `id` = '108' THEN 'Đang cập nhật'
WHEN `id` = '109' THEN 'Đang cập nhật'
WHEN `id` = '110' THEN 'Đang cập nhật'
WHEN `id` = '111' THEN 'Đang cập nhật'
WHEN `id` = '112' THEN 'Đang cập nhật'
WHEN `id` = '113' THEN 'Đang cập nhật'
WHEN `id` = '114' THEN 'Đang cập nhật'
WHEN `id` = '115' THEN 'Đang cập nhật'
WHEN `id` = '116' THEN 'Đang cập nhật'
ELSE `state` END, `view` = CASE 
WHEN `id` = '107' THEN '39479'
WHEN `id` = '108' THEN '54726'
WHEN `id` = '109' THEN '68872'
WHEN `id` = '110' THEN '132275'
WHEN `id` = '111' THEN '10277'
WHEN `id` = '112' THEN '4133'
WHEN `id` = '113' THEN '262714'
WHEN `id` = '114' THEN '58220'
WHEN `id` = '115' THEN '302348'
WHEN `id` = '116' THEN '7903'
ELSE `view` END, `rating` = CASE 
WHEN `id` = '107' THEN '9.21  out of 10'
WHEN `id` = '108' THEN '8.21  out of 10'
WHEN `id` = '109' THEN '9.30  out of 10'
WHEN `id` = '110' THEN '9.31  out of 10'
WHEN `id` = '111' THEN '8.64  out of 10'
WHEN `id` = '112' THEN '9.90  out of 10'
WHEN `id` = '113' THEN '9.31  out of 10'
WHEN `id` = '114' THEN '8.07  out of 10'
WHEN `id` = '115' THEN '8.65  out of 10'
WHEN `id` = '116' THEN '9.78  out of 10'
ELSE `rating` END, `source_id` = CASE 
WHEN `id` = '107' THEN '3702'
WHEN `id` = '108' THEN '3746'
WHEN `id` = '109' THEN '2688'
WHEN `id` = '110' THEN '6128'
WHEN `id` = '111' THEN '6421'
WHEN `id` = '112' THEN '6185'
WHEN `id` = '113' THEN '44'
WHEN `id` = '114' THEN '3247'
WHEN `id` = '115' THEN '2749'
WHEN `id` = '116' THEN '6442'
ELSE `source_id` END, `intro` = CASE 
WHEN `id` = '107' THEN 'Đọc truyện <a href=\"http://webtruyen.com/dai-dao-doc-hanh/\">Đại Đạo Độc Hành</a> của tác giả Vu Ngoại Giang Sơn là một truyện khá đặc sắc, cũng là câu chuyện võ hiệp nhưng tác phẩm thực sự để lại ấn tượng cho người đọc bởi lối viết văn và nội dụng truyện. Nhiều khi đọc truyện ta cảm nhận được mình đang thực sự chu du vào thế giới <a href=\"http://webtruyen.com/tien-hiep/\">truyện tiên hiệp</a> đầy màu sắc kì ảo này.<br/><br/><a href=\"http://webtruyen.com/\">Truyện</a> là hành trình tu tiên, hành trình trên một không gian khác lạ, con đường đi qua không dài nhưng cũng chẳng ngắn, để đi được chặng đường này, cần nhất là sự kiên trì, là tâm căn muốn theo đuổi sự nghiệp võ học.<br/><br/>Ba nghìn Tả đạo, tám trăm bàng môn, thượng môn một trăm lẻ tám, ở nơi này tu giả nhiều như kiến thời đại.<br/><br/>Tu giả hướng đến tay cầm ngũ hành, chân đạp âm dương, siêu thoát sinh tử luân hồi, theo đuổi vĩnh hằng đại đạo.<br/><br/>Khổ tu, du lịch, ngộ đạo, tử chiến, trải qua vạn kiếp, giữ vững lòng tin, cuối cùng sẽ đi đến đỉnh cao, vừa xem cửu thiên mịt mù.<br/><br/>Ta rốt cuộc đứng tại đỉnh cửu thiên, mới phát hiện cần cù cầu đại đạo, chẳng qua đường ta đã đi, đường này chỉ mới bắt đầu!<br/><br/>Đạo trời mênh mông, chỉ mình ta đi!<br/><br/> '
WHEN `id` = '108' THEN 'Một tuyệt phẩm <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> mới của tác giả Cóc Lang Thang nay được dịch và giới thiệu đến bạn đọc truyện Phần Thiên. Nội dung <a href=\"http://webtruyen.com/phan-thien/\">truyện phần thiên</a> không phải là câu truyện nói về người quân tử, mà là câu truyện nói về một kẻ vô sỉ, cực kỳ vô sỉ. Có tiền tài cứ lấy, có gái theo cứ nhận, có việc gì phải băn khoăn? Thường thì anh hùng chết trước, tiểu nhân sống dai đúng không? Vậy thì ta sẽ là một kẻ tiểu nhân.<br/><br/>Lời dịch giả : Đây là truyện đầu tiên mình ra riêng sau khi rất nhiều lần bị đồng đội bỏ bom, mình xin phép được dịch thể loại mà mình yêu thích, thể loại vô sỉ, rất mong mọi người ủng hộ. Xin cảm ơn. '
WHEN `id` = '109' THEN 'Bạn đang đọc truyện Chân Linh Cửu Biến của tác giả Thụy Thu trên trang đọc truyện online.<br>Truyện kể về quá trình một tu sĩ phổ thông phấn đấu tu luyện, trưởng thành, bao gồm cả quá trình phát triển của một môn phái với bao quyền mưu, ám sát, chiến đấu, lợi ích và phấn đấu.<br><br>&nbsp;Đó là một tràng nhân yêu hai tộc đối kháng, rồi đại kiếp đến gần, để các bên hợp tung liên hoành tranh đấu cho sự tồn tại. <br><br>Trong truyện, tu sĩ Lục Bình đệ tử của Chân Linh phái chuyên tu thủy hệ công pháp những bằng nổ lực của mình đã từng bước thành công về luyện phù, luyện đan, tu thành thần thông giành lấy tiếng nói cho chính mình, chống lại những âm mưu đã ẩn giấu thâm sâu trong tu chân giới hàng vạn năm. '
WHEN `id` = '110' THEN 'So với <a href=\"http://webtruyen.com/chan-linh-cuu-bien/\">Châu Linh Cửu Biến</a> và <a href=\"http://webtruyen.com/dai-dao-doc-hanh/\">Đại Đạo Độc Hành</a> thì <a href=\"http://webtruyen.com/trieu-hoan-than-binh/\">Triệu Hoán Thần Binh</a> được đánh giá là tác phẩm có lối dẫn <a href=\"http://webtruyen.com/\">truyện hay</a>, khiến nhiều bạn đọc say mê với lối hành văn tinh tế của Hạ Nhật Dịch Lãnh.<br/><br/>*** <br/><br/>Nam nhân cầm thanh loan đao nhìn trường thương bị hủy ở trên tay hắn rơi xuống, khí tức anh hùng lập tức chấn động, lại xông qua chém giết.<br/><br/>Vu Nhai cảm thấy bất đắc dĩ.<br/><br/>Thế giới chết tiệt này, không có Huyền Binh bản mạng nhập thể chính là thấp hơn người một phần. Kẻ nắm giữ Huyền Binh chính là quý tộc. Huyền khí trong tay bọn họ, trăm phần trăm truyền chính là Huyền Binh huyền khí bản mạng nhập thể. Trừ khi chất liệu vũ khí của ngươi vô cùng tốt, còn không, gần như chỉ vừa va chạm sẽ lập tức vỡ nát. Hắn chỉ là một tiểu binh thủ thành nho nhỏ, có thể được phân phối vũ khí chất liệu tốt sao? Nói thừa!<br/><br/>Nhìn thấy thanh loan đao kia đâm tới, từ huyền khí phía trên thanh loan đao có thể phán đoán được, người này hẳn là cao hơn so với mình mấy đẳng cấp. Hắn lại có Huyền Binh, hẳn là bối cảnh không nhỏ. Chất lượng Huyền Binh của hắn chí ít phải đạt được tam giai. Vậy phải làm sao?<br/><br/>*** <br/><br/>Mời bạn đọc khám phá về thế giới <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> với nhân vật Vu Nhai. So với những vị anh hùng quả cảm thì Vu Nhai quả thực là nhân vật tài sắc vẹn toàn, dù không hơn thắng thua nhưng những kẻ tiểu nhân vẫn khiến các anh hùng phải ái ngại.<br/><br/> '
WHEN `id` = '111' THEN 'So với những tác phẩm cùng loại khác thì <a href=\"http://webtruyen.com/truyen-moi-dang/\">truyện mới</a> <a href=\"http://webtruyen.com/trong-sinh-tai-nhan-gioi/\">Trọng Sinh Tại Nhẫn Giới</a> mang đến cho bạn đọc những yếu tố huyền huyễn và mờ ảo đầy ly kì.<br/><br/>*** <br/><br/>Mặt trăng tròn vằng vặc chiếu lên trên một ngôi làng... Trong một căn nhà gỗ, tiếng gào thét của một vị nữ nhân liên tục phát ra: “A, a, a... đau quá!”<br/><br/>Một vị nữ tính khác phát ra âm thanh: “Cố lên phu nhân, sắp ra rồi! Sắp ra rồi!”<br/><br/>Một người thanh niên đi đi lại lại ở phía cảnh cửa. Hắn nhìn về phía sau đám cánh cửa được thiết kế bằng gỗ. Những tấm dán bằng giấy cổ điện và trang nhã được phủ lên trên đó. Thông qua ánh sáng ở bên trong hiện lên những bóng người. Người thanh niên khoảng hơn hai mươi tuổi này liên tục đi đi lại lại, bộ dạng vô cùng khẩn trương và lo lắng.<br/><br/>Vị thanh niên này có mái tóc màu đen xám, con mắt khá to, hàng lông mày dày rậm và hơi cong. Sống mũi khá cao thể hiện sự ương ngạnh cùng với một cái trán rô bóng loáng. Hai hàng tóc được chải sang hai bên. Trên khuôn mặt thể hiện sự cao ngạo và tự tin. Bộ dạng của hắn khá là đẹp trai. Tuy nhiên bộ dạng của hắn lúc này thì vô cùng lo lắng.<br/><br/>*** <br/><br/>Liên tiếp những tình tiết gay cấn và hấp dẫn sẽ có trong truyện <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a>, mời bạn đọc khám phá. <br/><br/> '
WHEN `id` = '112' THEN 'Truyện <a href=\"http://webtruyen.com/tro-choi-tu-vong-luan-hoi/\">Trò Chơi Tử Vong Luân Hồi</a> sẽ đưa chúng ta đến những năng lực trong trò chơi mà có thể sẽ áp dụng năng lực đó ra ngoài đời thực. Khi áp dụng những kỹ năng ra đời thực cũng là điều không hề dễ dàng...<br/><br/>Người bạn của Tô Bằng chết ẩn mà khiến hắn đến với một trò chơi kỳ lạ. Công ty thần bí kỳ lạ, đồng nghiệp che giấu bí mật, cái chết kỳ lạ của đồng nghiệp...Tất cả đều khiến cho Tô Bằng cuốn vào trong vòng xoáy.<br/><br/>Gia tộc xua đuổi Tô Bằng bởi những âm mưu trùng trùng điệp điệp. Liệu Tô Bằng sẽ áp dụng kỹ năng trong trò chơi ấy ra sao? Sức mạnh đạt đến cỡ nào?<br/><br/>Với tác phẩm <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> đem lại những tình tiết bất ngờ và thú vị cho bạn đọc. Một trò chơi nguy hiểm xoay vòng dẫn dắt bạn đọc đến với một thế giới với sức mạnh cực đại.<br/><br/>Mời bạn đọc khám phá <a href=\"http://webtruyen.com/\">truyện online</a> và tìm kiếm câu trả lời. <br/><br/> '
WHEN `id` = '113' THEN 'Bạn đang đọc truyện Tiên Quốc Đại Đế của tác giả Quan Kỳ trên trang đọc truyện online. Thiên hạ to lớn, duy ta chính thống! Dùng Thiên triều xu thế quét ngang thiên hạ tiên môn! Một cái cường giả tu \'Đế vương chi Đạo\', hàng lâm thế giới Tiên môn san sát, làm cho một cái người tu hành hèn mọn thế tục Vương triều, từng bước một đi đến cùng các đại đỉnh cấp Tiên môn bình khởi bình tọa. Vương triều pháp tắc là, trong thiên hạ chẳng lẽ vương thổ, suất thổ tân chẳng lẽ vương thần! Thiên hạ chính thống chỉ có một, hết thảy tiên môn, đều là tổ chức phi pháp! '
WHEN `id` = '114' THEN 'Đọc thể loại <a href=\"http://webtruyen.com/huyen-huyen/\">truyện huyền huyễn</a> người đọc không thể không bị hấp dẫn vào thế giới hư ảo của câu chuyện.<br/><br/>Có chút thực có chút giả, ảo tưởng nhưng lại rất thật. Một không gian mênh mang. <br/><br/>Hoa thiên long bệnh hoạn, khuyết tật, một người sinh ra mẹ đã chết trải qua bao bi phẫn của cuộc đời.<br/><br/>Vốn cứ tưởng mọi thứ đều mong manh như vậy nhưng nào ngờ lại có tình yêu...<br/><br/>Anh hùng gởi thân ở chiến trường.<br/><br/>Còn ta gởi thân chốn Thiên Đường.<br/><br/>…<br/><br/>Võ có thể thông thần, ý có thể thông thiên.<br/><br/>Thần ma ngạo thế, chư thiên vô hạn.<br/><br/>Bát cực thần điện, hùng bá vạn năm.<br/><br/>Tam giới song song, nhân thần chi chiến.<br/><br/>Cùng đọc tác phẩm <a href=\"http://webtruyen.com/thien-thanh/\">Thiên Thánh</a> để có thể cảm nhận hết được tứ thơ này nhé !!! '
WHEN `id` = '115' THEN 'Ai là fan của tác giả Trạch Trư hay là đã từng mất ăn mất ngủ với bộ truyện <a href=\"http://webtruyen.com/doc-bo-thien-ha/\">độc bộ thiên hạ</a> thì không thể bỏ qua bộ truyện <a href=\"http://webtruyen.com/de-ton\">Đế Tôn</a> này nhé. Đế tôn là truyện thuộc thể loại tiên hiệp. Truyện mới ra mắt ngày 20-2-2013. Hy vọng sẽ làm hài lọng bạn đọc mê <a href=\"http://webtruyen.com\">truyện</a>.<br/><br/>Võ đạo có thể Thông Thần!<br/><br/>Võ đạo tu luyện đến Thần Luân cảnh giới, liền có thể luyện tựu Thần Thông, siêu phàm thoát tục!<br/><br/>tác giả tác phẩm:<br/><br/>[ tiên hiệp ] đế tôn<br/><br/>[ tiên hiệp ] độc bộ thiên hạ<br/><br/>[ tiên hiệp ] sống lại tây du<br/><br/>[ huyền huyễn ] dã man vương tọa<br/><br/>[ tiên hiệp ]Thủy hử tiên đồ '
WHEN `id` = '116' THEN 'Truyện <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> <a href=\"http://webtruyen.com/hop-the-song-tu/\">Hợp Thể Song Tu</a> còn gọi tên khác là Chấp Ma của tác giả Mặc Thủy! Cốt truyện ban đầu có một chút sắc hợp lý, thế giới rộng lớn, nhân vật chính không não tàn, gái gú dám yêu dám hận.<br/><br/>Nhân vật chính là Ninh Phàm bị bạn chí thân phản bội hãm hại, để rồi nhờ cơ duyên mà ngẫu nhiên lấy được song tu đế bảo, từ đó bước trên con đường tu ma thiên hạ vô địch. Linh trang, pháp bảo, đạo quả, tiên vân, thiên sương hàn khí, địa mạch yêu hỏa... xuất hiện liên tục.<br/><br/>Năng lực được khám phá đại đạo âm dương, lấy thiên làm thê, lấy địa làm thiếp , lấy thương sinh làm đỉnh lô. Âm dương đại đạo, hợp thể song tu! Sức mạnh chỉ có thể phát huy khi tất cả đều trong một!<br/><br/>Mời bạn đọc theo dõi <a href=\"http://webtruyen.com/\">truyện online</a>. <br/><br/> '
ELSE `intro` END, `number_page` = CASE 
WHEN `id` = '107' THEN '8'
WHEN `id` = '108' THEN '11'
WHEN `id` = '109' THEN '12'
WHEN `id` = '110' THEN '39'
WHEN `id` = '111' THEN '2'
WHEN `id` = '112' THEN '3'
WHEN `id` = '113' THEN '27'
WHEN `id` = '114' THEN '11'
WHEN `id` = '115' THEN '42'
WHEN `id` = '116' THEN '1'
ELSE `number_page` END
WHERE `id` IN('107','108','109','110','111','112','113','114','115','116')
ERROR - 2015-05-19 06:51:23 --> Query error: Unknown column 'intro' in 'field list' - Invalid query: UPDATE `tbl_stories` SET `author` = CASE 
WHEN `id` = '107' THEN 'Vụ Ngoại Giang Sơn'
WHEN `id` = '108' THEN 'Cóc Lang Thang'
WHEN `id` = '109' THEN 'Thụy Thu'
WHEN `id` = '110' THEN 'Hạ Nhật Dịch Lãnh'
WHEN `id` = '111' THEN 'Deviltrigger'
WHEN `id` = '112' THEN 'Hoàng Kim Hải Ngạn'
WHEN `id` = '113' THEN 'Quan Kỳ'
WHEN `id` = '114' THEN 'Tâm Mộng Vô Ngân'
WHEN `id` = '115' THEN 'Trạch Trư'
WHEN `id` = '116' THEN 'Mặc Thủy'
ELSE `author` END, `type` = CASE 
WHEN `id` = '107' THEN 'Tiên hiệp'
WHEN `id` = '108' THEN 'Tiên hiệp'
WHEN `id` = '109' THEN 'Tiên hiệp'
WHEN `id` = '110' THEN 'Tiên hiệp'
WHEN `id` = '111' THEN 'Tiên hiệp'
WHEN `id` = '112' THEN 'Tiên hiệp'
WHEN `id` = '113' THEN 'Tiên hiệp , Quân sự'
WHEN `id` = '114' THEN 'Tiên hiệp'
WHEN `id` = '115' THEN 'Tiên hiệp'
WHEN `id` = '116' THEN 'Tiên hiệp'
ELSE `type` END, `source` = CASE 
WHEN `id` = '107' THEN 'tangthuvien.vn'
WHEN `id` = '108' THEN 'Vipvandan.vn'
WHEN `id` = '109' THEN 'Sưu tầm'
WHEN `id` = '110' THEN 'vipvandan'
WHEN `id` = '111' THEN 'tangthuvien'
WHEN `id` = '112' THEN 'vipvandan'
WHEN `id` = '113' THEN 'vipvandan'
WHEN `id` = '114' THEN 'Sưu tầm'
WHEN `id` = '115' THEN 'tangthuvien, vipvandan'
WHEN `id` = '116' THEN 'vipvandan'
ELSE `source` END, `state` = CASE 
WHEN `id` = '107' THEN 'Đang cập nhật'
WHEN `id` = '108' THEN 'Đang cập nhật'
WHEN `id` = '109' THEN 'Đang cập nhật'
WHEN `id` = '110' THEN 'Đang cập nhật'
WHEN `id` = '111' THEN 'Đang cập nhật'
WHEN `id` = '112' THEN 'Đang cập nhật'
WHEN `id` = '113' THEN 'Đang cập nhật'
WHEN `id` = '114' THEN 'Đang cập nhật'
WHEN `id` = '115' THEN 'Đang cập nhật'
WHEN `id` = '116' THEN 'Đang cập nhật'
ELSE `state` END, `view` = CASE 
WHEN `id` = '107' THEN '39479'
WHEN `id` = '108' THEN '54726'
WHEN `id` = '109' THEN '68872'
WHEN `id` = '110' THEN '132275'
WHEN `id` = '111' THEN '10277'
WHEN `id` = '112' THEN '4133'
WHEN `id` = '113' THEN '262714'
WHEN `id` = '114' THEN '58220'
WHEN `id` = '115' THEN '302348'
WHEN `id` = '116' THEN '7903'
ELSE `view` END, `rating` = CASE 
WHEN `id` = '107' THEN '9.21  out of 10'
WHEN `id` = '108' THEN '8.21  out of 10'
WHEN `id` = '109' THEN '9.30  out of 10'
WHEN `id` = '110' THEN '9.31  out of 10'
WHEN `id` = '111' THEN '8.64  out of 10'
WHEN `id` = '112' THEN '9.90  out of 10'
WHEN `id` = '113' THEN '9.31  out of 10'
WHEN `id` = '114' THEN '8.07  out of 10'
WHEN `id` = '115' THEN '8.65  out of 10'
WHEN `id` = '116' THEN '9.78  out of 10'
ELSE `rating` END, `crawler_stories_id` = CASE 
WHEN `id` = '107' THEN '3702'
WHEN `id` = '108' THEN '3746'
WHEN `id` = '109' THEN '2688'
WHEN `id` = '110' THEN '6128'
WHEN `id` = '111' THEN '6421'
WHEN `id` = '112' THEN '6185'
WHEN `id` = '113' THEN '44'
WHEN `id` = '114' THEN '3247'
WHEN `id` = '115' THEN '2749'
WHEN `id` = '116' THEN '6442'
ELSE `crawler_stories_id` END, `intro` = CASE 
WHEN `id` = '107' THEN 'Đọc truyện <a href=\"http://webtruyen.com/dai-dao-doc-hanh/\">Đại Đạo Độc Hành</a> của tác giả Vu Ngoại Giang Sơn là một truyện khá đặc sắc, cũng là câu chuyện võ hiệp nhưng tác phẩm thực sự để lại ấn tượng cho người đọc bởi lối viết văn và nội dụng truyện. Nhiều khi đọc truyện ta cảm nhận được mình đang thực sự chu du vào thế giới <a href=\"http://webtruyen.com/tien-hiep/\">truyện tiên hiệp</a> đầy màu sắc kì ảo này.<br/><br/><a href=\"http://webtruyen.com/\">Truyện</a> là hành trình tu tiên, hành trình trên một không gian khác lạ, con đường đi qua không dài nhưng cũng chẳng ngắn, để đi được chặng đường này, cần nhất là sự kiên trì, là tâm căn muốn theo đuổi sự nghiệp võ học.<br/><br/>Ba nghìn Tả đạo, tám trăm bàng môn, thượng môn một trăm lẻ tám, ở nơi này tu giả nhiều như kiến thời đại.<br/><br/>Tu giả hướng đến tay cầm ngũ hành, chân đạp âm dương, siêu thoát sinh tử luân hồi, theo đuổi vĩnh hằng đại đạo.<br/><br/>Khổ tu, du lịch, ngộ đạo, tử chiến, trải qua vạn kiếp, giữ vững lòng tin, cuối cùng sẽ đi đến đỉnh cao, vừa xem cửu thiên mịt mù.<br/><br/>Ta rốt cuộc đứng tại đỉnh cửu thiên, mới phát hiện cần cù cầu đại đạo, chẳng qua đường ta đã đi, đường này chỉ mới bắt đầu!<br/><br/>Đạo trời mênh mông, chỉ mình ta đi!<br/><br/> '
WHEN `id` = '108' THEN 'Một tuyệt phẩm <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> mới của tác giả Cóc Lang Thang nay được dịch và giới thiệu đến bạn đọc truyện Phần Thiên. Nội dung <a href=\"http://webtruyen.com/phan-thien/\">truyện phần thiên</a> không phải là câu truyện nói về người quân tử, mà là câu truyện nói về một kẻ vô sỉ, cực kỳ vô sỉ. Có tiền tài cứ lấy, có gái theo cứ nhận, có việc gì phải băn khoăn? Thường thì anh hùng chết trước, tiểu nhân sống dai đúng không? Vậy thì ta sẽ là một kẻ tiểu nhân.<br/><br/>Lời dịch giả : Đây là truyện đầu tiên mình ra riêng sau khi rất nhiều lần bị đồng đội bỏ bom, mình xin phép được dịch thể loại mà mình yêu thích, thể loại vô sỉ, rất mong mọi người ủng hộ. Xin cảm ơn. '
WHEN `id` = '109' THEN 'Bạn đang đọc truyện Chân Linh Cửu Biến của tác giả Thụy Thu trên trang đọc truyện online.<br>Truyện kể về quá trình một tu sĩ phổ thông phấn đấu tu luyện, trưởng thành, bao gồm cả quá trình phát triển của một môn phái với bao quyền mưu, ám sát, chiến đấu, lợi ích và phấn đấu.<br><br>&nbsp;Đó là một tràng nhân yêu hai tộc đối kháng, rồi đại kiếp đến gần, để các bên hợp tung liên hoành tranh đấu cho sự tồn tại. <br><br>Trong truyện, tu sĩ Lục Bình đệ tử của Chân Linh phái chuyên tu thủy hệ công pháp những bằng nổ lực của mình đã từng bước thành công về luyện phù, luyện đan, tu thành thần thông giành lấy tiếng nói cho chính mình, chống lại những âm mưu đã ẩn giấu thâm sâu trong tu chân giới hàng vạn năm. '
WHEN `id` = '110' THEN 'So với <a href=\"http://webtruyen.com/chan-linh-cuu-bien/\">Châu Linh Cửu Biến</a> và <a href=\"http://webtruyen.com/dai-dao-doc-hanh/\">Đại Đạo Độc Hành</a> thì <a href=\"http://webtruyen.com/trieu-hoan-than-binh/\">Triệu Hoán Thần Binh</a> được đánh giá là tác phẩm có lối dẫn <a href=\"http://webtruyen.com/\">truyện hay</a>, khiến nhiều bạn đọc say mê với lối hành văn tinh tế của Hạ Nhật Dịch Lãnh.<br/><br/>*** <br/><br/>Nam nhân cầm thanh loan đao nhìn trường thương bị hủy ở trên tay hắn rơi xuống, khí tức anh hùng lập tức chấn động, lại xông qua chém giết.<br/><br/>Vu Nhai cảm thấy bất đắc dĩ.<br/><br/>Thế giới chết tiệt này, không có Huyền Binh bản mạng nhập thể chính là thấp hơn người một phần. Kẻ nắm giữ Huyền Binh chính là quý tộc. Huyền khí trong tay bọn họ, trăm phần trăm truyền chính là Huyền Binh huyền khí bản mạng nhập thể. Trừ khi chất liệu vũ khí của ngươi vô cùng tốt, còn không, gần như chỉ vừa va chạm sẽ lập tức vỡ nát. Hắn chỉ là một tiểu binh thủ thành nho nhỏ, có thể được phân phối vũ khí chất liệu tốt sao? Nói thừa!<br/><br/>Nhìn thấy thanh loan đao kia đâm tới, từ huyền khí phía trên thanh loan đao có thể phán đoán được, người này hẳn là cao hơn so với mình mấy đẳng cấp. Hắn lại có Huyền Binh, hẳn là bối cảnh không nhỏ. Chất lượng Huyền Binh của hắn chí ít phải đạt được tam giai. Vậy phải làm sao?<br/><br/>*** <br/><br/>Mời bạn đọc khám phá về thế giới <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> với nhân vật Vu Nhai. So với những vị anh hùng quả cảm thì Vu Nhai quả thực là nhân vật tài sắc vẹn toàn, dù không hơn thắng thua nhưng những kẻ tiểu nhân vẫn khiến các anh hùng phải ái ngại.<br/><br/> '
WHEN `id` = '111' THEN 'So với những tác phẩm cùng loại khác thì <a href=\"http://webtruyen.com/truyen-moi-dang/\">truyện mới</a> <a href=\"http://webtruyen.com/trong-sinh-tai-nhan-gioi/\">Trọng Sinh Tại Nhẫn Giới</a> mang đến cho bạn đọc những yếu tố huyền huyễn và mờ ảo đầy ly kì.<br/><br/>*** <br/><br/>Mặt trăng tròn vằng vặc chiếu lên trên một ngôi làng... Trong một căn nhà gỗ, tiếng gào thét của một vị nữ nhân liên tục phát ra: “A, a, a... đau quá!”<br/><br/>Một vị nữ tính khác phát ra âm thanh: “Cố lên phu nhân, sắp ra rồi! Sắp ra rồi!”<br/><br/>Một người thanh niên đi đi lại lại ở phía cảnh cửa. Hắn nhìn về phía sau đám cánh cửa được thiết kế bằng gỗ. Những tấm dán bằng giấy cổ điện và trang nhã được phủ lên trên đó. Thông qua ánh sáng ở bên trong hiện lên những bóng người. Người thanh niên khoảng hơn hai mươi tuổi này liên tục đi đi lại lại, bộ dạng vô cùng khẩn trương và lo lắng.<br/><br/>Vị thanh niên này có mái tóc màu đen xám, con mắt khá to, hàng lông mày dày rậm và hơi cong. Sống mũi khá cao thể hiện sự ương ngạnh cùng với một cái trán rô bóng loáng. Hai hàng tóc được chải sang hai bên. Trên khuôn mặt thể hiện sự cao ngạo và tự tin. Bộ dạng của hắn khá là đẹp trai. Tuy nhiên bộ dạng của hắn lúc này thì vô cùng lo lắng.<br/><br/>*** <br/><br/>Liên tiếp những tình tiết gay cấn và hấp dẫn sẽ có trong truyện <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a>, mời bạn đọc khám phá. <br/><br/> '
WHEN `id` = '112' THEN 'Truyện <a href=\"http://webtruyen.com/tro-choi-tu-vong-luan-hoi/\">Trò Chơi Tử Vong Luân Hồi</a> sẽ đưa chúng ta đến những năng lực trong trò chơi mà có thể sẽ áp dụng năng lực đó ra ngoài đời thực. Khi áp dụng những kỹ năng ra đời thực cũng là điều không hề dễ dàng...<br/><br/>Người bạn của Tô Bằng chết ẩn mà khiến hắn đến với một trò chơi kỳ lạ. Công ty thần bí kỳ lạ, đồng nghiệp che giấu bí mật, cái chết kỳ lạ của đồng nghiệp...Tất cả đều khiến cho Tô Bằng cuốn vào trong vòng xoáy.<br/><br/>Gia tộc xua đuổi Tô Bằng bởi những âm mưu trùng trùng điệp điệp. Liệu Tô Bằng sẽ áp dụng kỹ năng trong trò chơi ấy ra sao? Sức mạnh đạt đến cỡ nào?<br/><br/>Với tác phẩm <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> đem lại những tình tiết bất ngờ và thú vị cho bạn đọc. Một trò chơi nguy hiểm xoay vòng dẫn dắt bạn đọc đến với một thế giới với sức mạnh cực đại.<br/><br/>Mời bạn đọc khám phá <a href=\"http://webtruyen.com/\">truyện online</a> và tìm kiếm câu trả lời. <br/><br/> '
WHEN `id` = '113' THEN 'Bạn đang đọc truyện Tiên Quốc Đại Đế của tác giả Quan Kỳ trên trang đọc truyện online. Thiên hạ to lớn, duy ta chính thống! Dùng Thiên triều xu thế quét ngang thiên hạ tiên môn! Một cái cường giả tu \'Đế vương chi Đạo\', hàng lâm thế giới Tiên môn san sát, làm cho một cái người tu hành hèn mọn thế tục Vương triều, từng bước một đi đến cùng các đại đỉnh cấp Tiên môn bình khởi bình tọa. Vương triều pháp tắc là, trong thiên hạ chẳng lẽ vương thổ, suất thổ tân chẳng lẽ vương thần! Thiên hạ chính thống chỉ có một, hết thảy tiên môn, đều là tổ chức phi pháp! '
WHEN `id` = '114' THEN 'Đọc thể loại <a href=\"http://webtruyen.com/huyen-huyen/\">truyện huyền huyễn</a> người đọc không thể không bị hấp dẫn vào thế giới hư ảo của câu chuyện.<br/><br/>Có chút thực có chút giả, ảo tưởng nhưng lại rất thật. Một không gian mênh mang. <br/><br/>Hoa thiên long bệnh hoạn, khuyết tật, một người sinh ra mẹ đã chết trải qua bao bi phẫn của cuộc đời.<br/><br/>Vốn cứ tưởng mọi thứ đều mong manh như vậy nhưng nào ngờ lại có tình yêu...<br/><br/>Anh hùng gởi thân ở chiến trường.<br/><br/>Còn ta gởi thân chốn Thiên Đường.<br/><br/>…<br/><br/>Võ có thể thông thần, ý có thể thông thiên.<br/><br/>Thần ma ngạo thế, chư thiên vô hạn.<br/><br/>Bát cực thần điện, hùng bá vạn năm.<br/><br/>Tam giới song song, nhân thần chi chiến.<br/><br/>Cùng đọc tác phẩm <a href=\"http://webtruyen.com/thien-thanh/\">Thiên Thánh</a> để có thể cảm nhận hết được tứ thơ này nhé !!! '
WHEN `id` = '115' THEN 'Ai là fan của tác giả Trạch Trư hay là đã từng mất ăn mất ngủ với bộ truyện <a href=\"http://webtruyen.com/doc-bo-thien-ha/\">độc bộ thiên hạ</a> thì không thể bỏ qua bộ truyện <a href=\"http://webtruyen.com/de-ton\">Đế Tôn</a> này nhé. Đế tôn là truyện thuộc thể loại tiên hiệp. Truyện mới ra mắt ngày 20-2-2013. Hy vọng sẽ làm hài lọng bạn đọc mê <a href=\"http://webtruyen.com\">truyện</a>.<br/><br/>Võ đạo có thể Thông Thần!<br/><br/>Võ đạo tu luyện đến Thần Luân cảnh giới, liền có thể luyện tựu Thần Thông, siêu phàm thoát tục!<br/><br/>tác giả tác phẩm:<br/><br/>[ tiên hiệp ] đế tôn<br/><br/>[ tiên hiệp ] độc bộ thiên hạ<br/><br/>[ tiên hiệp ] sống lại tây du<br/><br/>[ huyền huyễn ] dã man vương tọa<br/><br/>[ tiên hiệp ]Thủy hử tiên đồ '
WHEN `id` = '116' THEN 'Truyện <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> <a href=\"http://webtruyen.com/hop-the-song-tu/\">Hợp Thể Song Tu</a> còn gọi tên khác là Chấp Ma của tác giả Mặc Thủy! Cốt truyện ban đầu có một chút sắc hợp lý, thế giới rộng lớn, nhân vật chính không não tàn, gái gú dám yêu dám hận.<br/><br/>Nhân vật chính là Ninh Phàm bị bạn chí thân phản bội hãm hại, để rồi nhờ cơ duyên mà ngẫu nhiên lấy được song tu đế bảo, từ đó bước trên con đường tu ma thiên hạ vô địch. Linh trang, pháp bảo, đạo quả, tiên vân, thiên sương hàn khí, địa mạch yêu hỏa... xuất hiện liên tục.<br/><br/>Năng lực được khám phá đại đạo âm dương, lấy thiên làm thê, lấy địa làm thiếp , lấy thương sinh làm đỉnh lô. Âm dương đại đạo, hợp thể song tu! Sức mạnh chỉ có thể phát huy khi tất cả đều trong một!<br/><br/>Mời bạn đọc theo dõi <a href=\"http://webtruyen.com/\">truyện online</a>. <br/><br/> '
ELSE `intro` END, `number_page` = CASE 
WHEN `id` = '107' THEN '8'
WHEN `id` = '108' THEN '11'
WHEN `id` = '109' THEN '12'
WHEN `id` = '110' THEN '39'
WHEN `id` = '111' THEN '2'
WHEN `id` = '112' THEN '3'
WHEN `id` = '113' THEN '27'
WHEN `id` = '114' THEN '11'
WHEN `id` = '115' THEN '42'
WHEN `id` = '116' THEN '1'
ELSE `number_page` END
WHERE `id` IN('107','108','109','110','111','112','113','114','115','116')
ERROR - 2015-05-19 06:51:52 --> Query error: Unknown column 'number_page' in 'field list' - Invalid query: UPDATE `tbl_stories` SET `author` = CASE 
WHEN `id` = '107' THEN 'Vụ Ngoại Giang Sơn'
WHEN `id` = '108' THEN 'Cóc Lang Thang'
WHEN `id` = '109' THEN 'Thụy Thu'
WHEN `id` = '110' THEN 'Hạ Nhật Dịch Lãnh'
WHEN `id` = '111' THEN 'Deviltrigger'
WHEN `id` = '112' THEN 'Hoàng Kim Hải Ngạn'
WHEN `id` = '113' THEN 'Quan Kỳ'
WHEN `id` = '114' THEN 'Tâm Mộng Vô Ngân'
WHEN `id` = '115' THEN 'Trạch Trư'
WHEN `id` = '116' THEN 'Mặc Thủy'
ELSE `author` END, `type` = CASE 
WHEN `id` = '107' THEN 'Tiên hiệp'
WHEN `id` = '108' THEN 'Tiên hiệp'
WHEN `id` = '109' THEN 'Tiên hiệp'
WHEN `id` = '110' THEN 'Tiên hiệp'
WHEN `id` = '111' THEN 'Tiên hiệp'
WHEN `id` = '112' THEN 'Tiên hiệp'
WHEN `id` = '113' THEN 'Tiên hiệp , Quân sự'
WHEN `id` = '114' THEN 'Tiên hiệp'
WHEN `id` = '115' THEN 'Tiên hiệp'
WHEN `id` = '116' THEN 'Tiên hiệp'
ELSE `type` END, `source` = CASE 
WHEN `id` = '107' THEN 'tangthuvien.vn'
WHEN `id` = '108' THEN 'Vipvandan.vn'
WHEN `id` = '109' THEN 'Sưu tầm'
WHEN `id` = '110' THEN 'vipvandan'
WHEN `id` = '111' THEN 'tangthuvien'
WHEN `id` = '112' THEN 'vipvandan'
WHEN `id` = '113' THEN 'vipvandan'
WHEN `id` = '114' THEN 'Sưu tầm'
WHEN `id` = '115' THEN 'tangthuvien, vipvandan'
WHEN `id` = '116' THEN 'vipvandan'
ELSE `source` END, `state` = CASE 
WHEN `id` = '107' THEN 'Đang cập nhật'
WHEN `id` = '108' THEN 'Đang cập nhật'
WHEN `id` = '109' THEN 'Đang cập nhật'
WHEN `id` = '110' THEN 'Đang cập nhật'
WHEN `id` = '111' THEN 'Đang cập nhật'
WHEN `id` = '112' THEN 'Đang cập nhật'
WHEN `id` = '113' THEN 'Đang cập nhật'
WHEN `id` = '114' THEN 'Đang cập nhật'
WHEN `id` = '115' THEN 'Đang cập nhật'
WHEN `id` = '116' THEN 'Đang cập nhật'
ELSE `state` END, `view` = CASE 
WHEN `id` = '107' THEN '39479'
WHEN `id` = '108' THEN '54726'
WHEN `id` = '109' THEN '68872'
WHEN `id` = '110' THEN '132275'
WHEN `id` = '111' THEN '10277'
WHEN `id` = '112' THEN '4133'
WHEN `id` = '113' THEN '262714'
WHEN `id` = '114' THEN '58220'
WHEN `id` = '115' THEN '302348'
WHEN `id` = '116' THEN '7903'
ELSE `view` END, `rating` = CASE 
WHEN `id` = '107' THEN '9.21  out of 10'
WHEN `id` = '108' THEN '8.21  out of 10'
WHEN `id` = '109' THEN '9.30  out of 10'
WHEN `id` = '110' THEN '9.31  out of 10'
WHEN `id` = '111' THEN '8.64  out of 10'
WHEN `id` = '112' THEN '9.90  out of 10'
WHEN `id` = '113' THEN '9.31  out of 10'
WHEN `id` = '114' THEN '8.07  out of 10'
WHEN `id` = '115' THEN '8.65  out of 10'
WHEN `id` = '116' THEN '9.78  out of 10'
ELSE `rating` END, `crawler_stories_id` = CASE 
WHEN `id` = '107' THEN '3702'
WHEN `id` = '108' THEN '3746'
WHEN `id` = '109' THEN '2688'
WHEN `id` = '110' THEN '6128'
WHEN `id` = '111' THEN '6421'
WHEN `id` = '112' THEN '6185'
WHEN `id` = '113' THEN '44'
WHEN `id` = '114' THEN '3247'
WHEN `id` = '115' THEN '2749'
WHEN `id` = '116' THEN '6442'
ELSE `crawler_stories_id` END, `description` = CASE 
WHEN `id` = '107' THEN 'Đọc truyện <a href=\"http://webtruyen.com/dai-dao-doc-hanh/\">Đại Đạo Độc Hành</a> của tác giả Vu Ngoại Giang Sơn là một truyện khá đặc sắc, cũng là câu chuyện võ hiệp nhưng tác phẩm thực sự để lại ấn tượng cho người đọc bởi lối viết văn và nội dụng truyện. Nhiều khi đọc truyện ta cảm nhận được mình đang thực sự chu du vào thế giới <a href=\"http://webtruyen.com/tien-hiep/\">truyện tiên hiệp</a> đầy màu sắc kì ảo này.<br/><br/><a href=\"http://webtruyen.com/\">Truyện</a> là hành trình tu tiên, hành trình trên một không gian khác lạ, con đường đi qua không dài nhưng cũng chẳng ngắn, để đi được chặng đường này, cần nhất là sự kiên trì, là tâm căn muốn theo đuổi sự nghiệp võ học.<br/><br/>Ba nghìn Tả đạo, tám trăm bàng môn, thượng môn một trăm lẻ tám, ở nơi này tu giả nhiều như kiến thời đại.<br/><br/>Tu giả hướng đến tay cầm ngũ hành, chân đạp âm dương, siêu thoát sinh tử luân hồi, theo đuổi vĩnh hằng đại đạo.<br/><br/>Khổ tu, du lịch, ngộ đạo, tử chiến, trải qua vạn kiếp, giữ vững lòng tin, cuối cùng sẽ đi đến đỉnh cao, vừa xem cửu thiên mịt mù.<br/><br/>Ta rốt cuộc đứng tại đỉnh cửu thiên, mới phát hiện cần cù cầu đại đạo, chẳng qua đường ta đã đi, đường này chỉ mới bắt đầu!<br/><br/>Đạo trời mênh mông, chỉ mình ta đi!<br/><br/> '
WHEN `id` = '108' THEN 'Một tuyệt phẩm <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> mới của tác giả Cóc Lang Thang nay được dịch và giới thiệu đến bạn đọc truyện Phần Thiên. Nội dung <a href=\"http://webtruyen.com/phan-thien/\">truyện phần thiên</a> không phải là câu truyện nói về người quân tử, mà là câu truyện nói về một kẻ vô sỉ, cực kỳ vô sỉ. Có tiền tài cứ lấy, có gái theo cứ nhận, có việc gì phải băn khoăn? Thường thì anh hùng chết trước, tiểu nhân sống dai đúng không? Vậy thì ta sẽ là một kẻ tiểu nhân.<br/><br/>Lời dịch giả : Đây là truyện đầu tiên mình ra riêng sau khi rất nhiều lần bị đồng đội bỏ bom, mình xin phép được dịch thể loại mà mình yêu thích, thể loại vô sỉ, rất mong mọi người ủng hộ. Xin cảm ơn. '
WHEN `id` = '109' THEN 'Bạn đang đọc truyện Chân Linh Cửu Biến của tác giả Thụy Thu trên trang đọc truyện online.<br>Truyện kể về quá trình một tu sĩ phổ thông phấn đấu tu luyện, trưởng thành, bao gồm cả quá trình phát triển của một môn phái với bao quyền mưu, ám sát, chiến đấu, lợi ích và phấn đấu.<br><br>&nbsp;Đó là một tràng nhân yêu hai tộc đối kháng, rồi đại kiếp đến gần, để các bên hợp tung liên hoành tranh đấu cho sự tồn tại. <br><br>Trong truyện, tu sĩ Lục Bình đệ tử của Chân Linh phái chuyên tu thủy hệ công pháp những bằng nổ lực của mình đã từng bước thành công về luyện phù, luyện đan, tu thành thần thông giành lấy tiếng nói cho chính mình, chống lại những âm mưu đã ẩn giấu thâm sâu trong tu chân giới hàng vạn năm. '
WHEN `id` = '110' THEN 'So với <a href=\"http://webtruyen.com/chan-linh-cuu-bien/\">Châu Linh Cửu Biến</a> và <a href=\"http://webtruyen.com/dai-dao-doc-hanh/\">Đại Đạo Độc Hành</a> thì <a href=\"http://webtruyen.com/trieu-hoan-than-binh/\">Triệu Hoán Thần Binh</a> được đánh giá là tác phẩm có lối dẫn <a href=\"http://webtruyen.com/\">truyện hay</a>, khiến nhiều bạn đọc say mê với lối hành văn tinh tế của Hạ Nhật Dịch Lãnh.<br/><br/>*** <br/><br/>Nam nhân cầm thanh loan đao nhìn trường thương bị hủy ở trên tay hắn rơi xuống, khí tức anh hùng lập tức chấn động, lại xông qua chém giết.<br/><br/>Vu Nhai cảm thấy bất đắc dĩ.<br/><br/>Thế giới chết tiệt này, không có Huyền Binh bản mạng nhập thể chính là thấp hơn người một phần. Kẻ nắm giữ Huyền Binh chính là quý tộc. Huyền khí trong tay bọn họ, trăm phần trăm truyền chính là Huyền Binh huyền khí bản mạng nhập thể. Trừ khi chất liệu vũ khí của ngươi vô cùng tốt, còn không, gần như chỉ vừa va chạm sẽ lập tức vỡ nát. Hắn chỉ là một tiểu binh thủ thành nho nhỏ, có thể được phân phối vũ khí chất liệu tốt sao? Nói thừa!<br/><br/>Nhìn thấy thanh loan đao kia đâm tới, từ huyền khí phía trên thanh loan đao có thể phán đoán được, người này hẳn là cao hơn so với mình mấy đẳng cấp. Hắn lại có Huyền Binh, hẳn là bối cảnh không nhỏ. Chất lượng Huyền Binh của hắn chí ít phải đạt được tam giai. Vậy phải làm sao?<br/><br/>*** <br/><br/>Mời bạn đọc khám phá về thế giới <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> với nhân vật Vu Nhai. So với những vị anh hùng quả cảm thì Vu Nhai quả thực là nhân vật tài sắc vẹn toàn, dù không hơn thắng thua nhưng những kẻ tiểu nhân vẫn khiến các anh hùng phải ái ngại.<br/><br/> '
WHEN `id` = '111' THEN 'So với những tác phẩm cùng loại khác thì <a href=\"http://webtruyen.com/truyen-moi-dang/\">truyện mới</a> <a href=\"http://webtruyen.com/trong-sinh-tai-nhan-gioi/\">Trọng Sinh Tại Nhẫn Giới</a> mang đến cho bạn đọc những yếu tố huyền huyễn và mờ ảo đầy ly kì.<br/><br/>*** <br/><br/>Mặt trăng tròn vằng vặc chiếu lên trên một ngôi làng... Trong một căn nhà gỗ, tiếng gào thét của một vị nữ nhân liên tục phát ra: “A, a, a... đau quá!”<br/><br/>Một vị nữ tính khác phát ra âm thanh: “Cố lên phu nhân, sắp ra rồi! Sắp ra rồi!”<br/><br/>Một người thanh niên đi đi lại lại ở phía cảnh cửa. Hắn nhìn về phía sau đám cánh cửa được thiết kế bằng gỗ. Những tấm dán bằng giấy cổ điện và trang nhã được phủ lên trên đó. Thông qua ánh sáng ở bên trong hiện lên những bóng người. Người thanh niên khoảng hơn hai mươi tuổi này liên tục đi đi lại lại, bộ dạng vô cùng khẩn trương và lo lắng.<br/><br/>Vị thanh niên này có mái tóc màu đen xám, con mắt khá to, hàng lông mày dày rậm và hơi cong. Sống mũi khá cao thể hiện sự ương ngạnh cùng với một cái trán rô bóng loáng. Hai hàng tóc được chải sang hai bên. Trên khuôn mặt thể hiện sự cao ngạo và tự tin. Bộ dạng của hắn khá là đẹp trai. Tuy nhiên bộ dạng của hắn lúc này thì vô cùng lo lắng.<br/><br/>*** <br/><br/>Liên tiếp những tình tiết gay cấn và hấp dẫn sẽ có trong truyện <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a>, mời bạn đọc khám phá. <br/><br/> '
WHEN `id` = '112' THEN 'Truyện <a href=\"http://webtruyen.com/tro-choi-tu-vong-luan-hoi/\">Trò Chơi Tử Vong Luân Hồi</a> sẽ đưa chúng ta đến những năng lực trong trò chơi mà có thể sẽ áp dụng năng lực đó ra ngoài đời thực. Khi áp dụng những kỹ năng ra đời thực cũng là điều không hề dễ dàng...<br/><br/>Người bạn của Tô Bằng chết ẩn mà khiến hắn đến với một trò chơi kỳ lạ. Công ty thần bí kỳ lạ, đồng nghiệp che giấu bí mật, cái chết kỳ lạ của đồng nghiệp...Tất cả đều khiến cho Tô Bằng cuốn vào trong vòng xoáy.<br/><br/>Gia tộc xua đuổi Tô Bằng bởi những âm mưu trùng trùng điệp điệp. Liệu Tô Bằng sẽ áp dụng kỹ năng trong trò chơi ấy ra sao? Sức mạnh đạt đến cỡ nào?<br/><br/>Với tác phẩm <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> đem lại những tình tiết bất ngờ và thú vị cho bạn đọc. Một trò chơi nguy hiểm xoay vòng dẫn dắt bạn đọc đến với một thế giới với sức mạnh cực đại.<br/><br/>Mời bạn đọc khám phá <a href=\"http://webtruyen.com/\">truyện online</a> và tìm kiếm câu trả lời. <br/><br/> '
WHEN `id` = '113' THEN 'Bạn đang đọc truyện Tiên Quốc Đại Đế của tác giả Quan Kỳ trên trang đọc truyện online. Thiên hạ to lớn, duy ta chính thống! Dùng Thiên triều xu thế quét ngang thiên hạ tiên môn! Một cái cường giả tu \'Đế vương chi Đạo\', hàng lâm thế giới Tiên môn san sát, làm cho một cái người tu hành hèn mọn thế tục Vương triều, từng bước một đi đến cùng các đại đỉnh cấp Tiên môn bình khởi bình tọa. Vương triều pháp tắc là, trong thiên hạ chẳng lẽ vương thổ, suất thổ tân chẳng lẽ vương thần! Thiên hạ chính thống chỉ có một, hết thảy tiên môn, đều là tổ chức phi pháp! '
WHEN `id` = '114' THEN 'Đọc thể loại <a href=\"http://webtruyen.com/huyen-huyen/\">truyện huyền huyễn</a> người đọc không thể không bị hấp dẫn vào thế giới hư ảo của câu chuyện.<br/><br/>Có chút thực có chút giả, ảo tưởng nhưng lại rất thật. Một không gian mênh mang. <br/><br/>Hoa thiên long bệnh hoạn, khuyết tật, một người sinh ra mẹ đã chết trải qua bao bi phẫn của cuộc đời.<br/><br/>Vốn cứ tưởng mọi thứ đều mong manh như vậy nhưng nào ngờ lại có tình yêu...<br/><br/>Anh hùng gởi thân ở chiến trường.<br/><br/>Còn ta gởi thân chốn Thiên Đường.<br/><br/>…<br/><br/>Võ có thể thông thần, ý có thể thông thiên.<br/><br/>Thần ma ngạo thế, chư thiên vô hạn.<br/><br/>Bát cực thần điện, hùng bá vạn năm.<br/><br/>Tam giới song song, nhân thần chi chiến.<br/><br/>Cùng đọc tác phẩm <a href=\"http://webtruyen.com/thien-thanh/\">Thiên Thánh</a> để có thể cảm nhận hết được tứ thơ này nhé !!! '
WHEN `id` = '115' THEN 'Ai là fan của tác giả Trạch Trư hay là đã từng mất ăn mất ngủ với bộ truyện <a href=\"http://webtruyen.com/doc-bo-thien-ha/\">độc bộ thiên hạ</a> thì không thể bỏ qua bộ truyện <a href=\"http://webtruyen.com/de-ton\">Đế Tôn</a> này nhé. Đế tôn là truyện thuộc thể loại tiên hiệp. Truyện mới ra mắt ngày 20-2-2013. Hy vọng sẽ làm hài lọng bạn đọc mê <a href=\"http://webtruyen.com\">truyện</a>.<br/><br/>Võ đạo có thể Thông Thần!<br/><br/>Võ đạo tu luyện đến Thần Luân cảnh giới, liền có thể luyện tựu Thần Thông, siêu phàm thoát tục!<br/><br/>tác giả tác phẩm:<br/><br/>[ tiên hiệp ] đế tôn<br/><br/>[ tiên hiệp ] độc bộ thiên hạ<br/><br/>[ tiên hiệp ] sống lại tây du<br/><br/>[ huyền huyễn ] dã man vương tọa<br/><br/>[ tiên hiệp ]Thủy hử tiên đồ '
WHEN `id` = '116' THEN 'Truyện <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> <a href=\"http://webtruyen.com/hop-the-song-tu/\">Hợp Thể Song Tu</a> còn gọi tên khác là Chấp Ma của tác giả Mặc Thủy! Cốt truyện ban đầu có một chút sắc hợp lý, thế giới rộng lớn, nhân vật chính không não tàn, gái gú dám yêu dám hận.<br/><br/>Nhân vật chính là Ninh Phàm bị bạn chí thân phản bội hãm hại, để rồi nhờ cơ duyên mà ngẫu nhiên lấy được song tu đế bảo, từ đó bước trên con đường tu ma thiên hạ vô địch. Linh trang, pháp bảo, đạo quả, tiên vân, thiên sương hàn khí, địa mạch yêu hỏa... xuất hiện liên tục.<br/><br/>Năng lực được khám phá đại đạo âm dương, lấy thiên làm thê, lấy địa làm thiếp , lấy thương sinh làm đỉnh lô. Âm dương đại đạo, hợp thể song tu! Sức mạnh chỉ có thể phát huy khi tất cả đều trong một!<br/><br/>Mời bạn đọc theo dõi <a href=\"http://webtruyen.com/\">truyện online</a>. <br/><br/> '
ELSE `description` END, `number_page` = CASE 
WHEN `id` = '107' THEN '8'
WHEN `id` = '108' THEN '11'
WHEN `id` = '109' THEN '12'
WHEN `id` = '110' THEN '39'
WHEN `id` = '111' THEN '2'
WHEN `id` = '112' THEN '3'
WHEN `id` = '113' THEN '27'
WHEN `id` = '114' THEN '11'
WHEN `id` = '115' THEN '42'
WHEN `id` = '116' THEN '1'
ELSE `number_page` END
WHERE `id` IN('107','108','109','110','111','112','113','114','115','116')
ERROR - 2015-05-19 06:53:05 --> Query error: Unknown column 'number_page' in 'field list' - Invalid query: UPDATE `tbl_stories` SET `author` = CASE 
WHEN `id` = '107' THEN 'Vụ Ngoại Giang Sơn'
WHEN `id` = '108' THEN 'Cóc Lang Thang'
WHEN `id` = '109' THEN 'Thụy Thu'
WHEN `id` = '110' THEN 'Hạ Nhật Dịch Lãnh'
WHEN `id` = '111' THEN 'Deviltrigger'
WHEN `id` = '112' THEN 'Hoàng Kim Hải Ngạn'
WHEN `id` = '113' THEN 'Quan Kỳ'
WHEN `id` = '114' THEN 'Tâm Mộng Vô Ngân'
WHEN `id` = '115' THEN 'Trạch Trư'
WHEN `id` = '116' THEN 'Mặc Thủy'
ELSE `author` END, `type` = CASE 
WHEN `id` = '107' THEN 'Tiên hiệp'
WHEN `id` = '108' THEN 'Tiên hiệp'
WHEN `id` = '109' THEN 'Tiên hiệp'
WHEN `id` = '110' THEN 'Tiên hiệp'
WHEN `id` = '111' THEN 'Tiên hiệp'
WHEN `id` = '112' THEN 'Tiên hiệp'
WHEN `id` = '113' THEN 'Tiên hiệp , Quân sự'
WHEN `id` = '114' THEN 'Tiên hiệp'
WHEN `id` = '115' THEN 'Tiên hiệp'
WHEN `id` = '116' THEN 'Tiên hiệp'
ELSE `type` END, `source` = CASE 
WHEN `id` = '107' THEN 'tangthuvien.vn'
WHEN `id` = '108' THEN 'Vipvandan.vn'
WHEN `id` = '109' THEN 'Sưu tầm'
WHEN `id` = '110' THEN 'vipvandan'
WHEN `id` = '111' THEN 'tangthuvien'
WHEN `id` = '112' THEN 'vipvandan'
WHEN `id` = '113' THEN 'vipvandan'
WHEN `id` = '114' THEN 'Sưu tầm'
WHEN `id` = '115' THEN 'tangthuvien, vipvandan'
WHEN `id` = '116' THEN 'vipvandan'
ELSE `source` END, `state` = CASE 
WHEN `id` = '107' THEN 'Đang cập nhật'
WHEN `id` = '108' THEN 'Đang cập nhật'
WHEN `id` = '109' THEN 'Đang cập nhật'
WHEN `id` = '110' THEN 'Đang cập nhật'
WHEN `id` = '111' THEN 'Đang cập nhật'
WHEN `id` = '112' THEN 'Đang cập nhật'
WHEN `id` = '113' THEN 'Đang cập nhật'
WHEN `id` = '114' THEN 'Đang cập nhật'
WHEN `id` = '115' THEN 'Đang cập nhật'
WHEN `id` = '116' THEN 'Đang cập nhật'
ELSE `state` END, `view` = CASE 
WHEN `id` = '107' THEN '39479'
WHEN `id` = '108' THEN '54726'
WHEN `id` = '109' THEN '68872'
WHEN `id` = '110' THEN '132275'
WHEN `id` = '111' THEN '10277'
WHEN `id` = '112' THEN '4133'
WHEN `id` = '113' THEN '262714'
WHEN `id` = '114' THEN '58220'
WHEN `id` = '115' THEN '302348'
WHEN `id` = '116' THEN '7903'
ELSE `view` END, `rating` = CASE 
WHEN `id` = '107' THEN '9.21  out of 10'
WHEN `id` = '108' THEN '8.21  out of 10'
WHEN `id` = '109' THEN '9.30  out of 10'
WHEN `id` = '110' THEN '9.31  out of 10'
WHEN `id` = '111' THEN '8.64  out of 10'
WHEN `id` = '112' THEN '9.90  out of 10'
WHEN `id` = '113' THEN '9.31  out of 10'
WHEN `id` = '114' THEN '8.07  out of 10'
WHEN `id` = '115' THEN '8.65  out of 10'
WHEN `id` = '116' THEN '9.78  out of 10'
ELSE `rating` END, `crawler_stories_id` = CASE 
WHEN `id` = '107' THEN '3702'
WHEN `id` = '108' THEN '3746'
WHEN `id` = '109' THEN '2688'
WHEN `id` = '110' THEN '6128'
WHEN `id` = '111' THEN '6421'
WHEN `id` = '112' THEN '6185'
WHEN `id` = '113' THEN '44'
WHEN `id` = '114' THEN '3247'
WHEN `id` = '115' THEN '2749'
WHEN `id` = '116' THEN '6442'
ELSE `crawler_stories_id` END, `description` = CASE 
WHEN `id` = '107' THEN 'Đọc truyện <a href=\"http://webtruyen.com/dai-dao-doc-hanh/\">Đại Đạo Độc Hành</a> của tác giả Vu Ngoại Giang Sơn là một truyện khá đặc sắc, cũng là câu chuyện võ hiệp nhưng tác phẩm thực sự để lại ấn tượng cho người đọc bởi lối viết văn và nội dụng truyện. Nhiều khi đọc truyện ta cảm nhận được mình đang thực sự chu du vào thế giới <a href=\"http://webtruyen.com/tien-hiep/\">truyện tiên hiệp</a> đầy màu sắc kì ảo này.<br/><br/><a href=\"http://webtruyen.com/\">Truyện</a> là hành trình tu tiên, hành trình trên một không gian khác lạ, con đường đi qua không dài nhưng cũng chẳng ngắn, để đi được chặng đường này, cần nhất là sự kiên trì, là tâm căn muốn theo đuổi sự nghiệp võ học.<br/><br/>Ba nghìn Tả đạo, tám trăm bàng môn, thượng môn một trăm lẻ tám, ở nơi này tu giả nhiều như kiến thời đại.<br/><br/>Tu giả hướng đến tay cầm ngũ hành, chân đạp âm dương, siêu thoát sinh tử luân hồi, theo đuổi vĩnh hằng đại đạo.<br/><br/>Khổ tu, du lịch, ngộ đạo, tử chiến, trải qua vạn kiếp, giữ vững lòng tin, cuối cùng sẽ đi đến đỉnh cao, vừa xem cửu thiên mịt mù.<br/><br/>Ta rốt cuộc đứng tại đỉnh cửu thiên, mới phát hiện cần cù cầu đại đạo, chẳng qua đường ta đã đi, đường này chỉ mới bắt đầu!<br/><br/>Đạo trời mênh mông, chỉ mình ta đi!<br/><br/> '
WHEN `id` = '108' THEN 'Một tuyệt phẩm <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> mới của tác giả Cóc Lang Thang nay được dịch và giới thiệu đến bạn đọc truyện Phần Thiên. Nội dung <a href=\"http://webtruyen.com/phan-thien/\">truyện phần thiên</a> không phải là câu truyện nói về người quân tử, mà là câu truyện nói về một kẻ vô sỉ, cực kỳ vô sỉ. Có tiền tài cứ lấy, có gái theo cứ nhận, có việc gì phải băn khoăn? Thường thì anh hùng chết trước, tiểu nhân sống dai đúng không? Vậy thì ta sẽ là một kẻ tiểu nhân.<br/><br/>Lời dịch giả : Đây là truyện đầu tiên mình ra riêng sau khi rất nhiều lần bị đồng đội bỏ bom, mình xin phép được dịch thể loại mà mình yêu thích, thể loại vô sỉ, rất mong mọi người ủng hộ. Xin cảm ơn. '
WHEN `id` = '109' THEN 'Bạn đang đọc truyện Chân Linh Cửu Biến của tác giả Thụy Thu trên trang đọc truyện online.<br>Truyện kể về quá trình một tu sĩ phổ thông phấn đấu tu luyện, trưởng thành, bao gồm cả quá trình phát triển của một môn phái với bao quyền mưu, ám sát, chiến đấu, lợi ích và phấn đấu.<br><br>&nbsp;Đó là một tràng nhân yêu hai tộc đối kháng, rồi đại kiếp đến gần, để các bên hợp tung liên hoành tranh đấu cho sự tồn tại. <br><br>Trong truyện, tu sĩ Lục Bình đệ tử của Chân Linh phái chuyên tu thủy hệ công pháp những bằng nổ lực của mình đã từng bước thành công về luyện phù, luyện đan, tu thành thần thông giành lấy tiếng nói cho chính mình, chống lại những âm mưu đã ẩn giấu thâm sâu trong tu chân giới hàng vạn năm. '
WHEN `id` = '110' THEN 'So với <a href=\"http://webtruyen.com/chan-linh-cuu-bien/\">Châu Linh Cửu Biến</a> và <a href=\"http://webtruyen.com/dai-dao-doc-hanh/\">Đại Đạo Độc Hành</a> thì <a href=\"http://webtruyen.com/trieu-hoan-than-binh/\">Triệu Hoán Thần Binh</a> được đánh giá là tác phẩm có lối dẫn <a href=\"http://webtruyen.com/\">truyện hay</a>, khiến nhiều bạn đọc say mê với lối hành văn tinh tế của Hạ Nhật Dịch Lãnh.<br/><br/>*** <br/><br/>Nam nhân cầm thanh loan đao nhìn trường thương bị hủy ở trên tay hắn rơi xuống, khí tức anh hùng lập tức chấn động, lại xông qua chém giết.<br/><br/>Vu Nhai cảm thấy bất đắc dĩ.<br/><br/>Thế giới chết tiệt này, không có Huyền Binh bản mạng nhập thể chính là thấp hơn người một phần. Kẻ nắm giữ Huyền Binh chính là quý tộc. Huyền khí trong tay bọn họ, trăm phần trăm truyền chính là Huyền Binh huyền khí bản mạng nhập thể. Trừ khi chất liệu vũ khí của ngươi vô cùng tốt, còn không, gần như chỉ vừa va chạm sẽ lập tức vỡ nát. Hắn chỉ là một tiểu binh thủ thành nho nhỏ, có thể được phân phối vũ khí chất liệu tốt sao? Nói thừa!<br/><br/>Nhìn thấy thanh loan đao kia đâm tới, từ huyền khí phía trên thanh loan đao có thể phán đoán được, người này hẳn là cao hơn so với mình mấy đẳng cấp. Hắn lại có Huyền Binh, hẳn là bối cảnh không nhỏ. Chất lượng Huyền Binh của hắn chí ít phải đạt được tam giai. Vậy phải làm sao?<br/><br/>*** <br/><br/>Mời bạn đọc khám phá về thế giới <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> với nhân vật Vu Nhai. So với những vị anh hùng quả cảm thì Vu Nhai quả thực là nhân vật tài sắc vẹn toàn, dù không hơn thắng thua nhưng những kẻ tiểu nhân vẫn khiến các anh hùng phải ái ngại.<br/><br/> '
WHEN `id` = '111' THEN 'So với những tác phẩm cùng loại khác thì <a href=\"http://webtruyen.com/truyen-moi-dang/\">truyện mới</a> <a href=\"http://webtruyen.com/trong-sinh-tai-nhan-gioi/\">Trọng Sinh Tại Nhẫn Giới</a> mang đến cho bạn đọc những yếu tố huyền huyễn và mờ ảo đầy ly kì.<br/><br/>*** <br/><br/>Mặt trăng tròn vằng vặc chiếu lên trên một ngôi làng... Trong một căn nhà gỗ, tiếng gào thét của một vị nữ nhân liên tục phát ra: “A, a, a... đau quá!”<br/><br/>Một vị nữ tính khác phát ra âm thanh: “Cố lên phu nhân, sắp ra rồi! Sắp ra rồi!”<br/><br/>Một người thanh niên đi đi lại lại ở phía cảnh cửa. Hắn nhìn về phía sau đám cánh cửa được thiết kế bằng gỗ. Những tấm dán bằng giấy cổ điện và trang nhã được phủ lên trên đó. Thông qua ánh sáng ở bên trong hiện lên những bóng người. Người thanh niên khoảng hơn hai mươi tuổi này liên tục đi đi lại lại, bộ dạng vô cùng khẩn trương và lo lắng.<br/><br/>Vị thanh niên này có mái tóc màu đen xám, con mắt khá to, hàng lông mày dày rậm và hơi cong. Sống mũi khá cao thể hiện sự ương ngạnh cùng với một cái trán rô bóng loáng. Hai hàng tóc được chải sang hai bên. Trên khuôn mặt thể hiện sự cao ngạo và tự tin. Bộ dạng của hắn khá là đẹp trai. Tuy nhiên bộ dạng của hắn lúc này thì vô cùng lo lắng.<br/><br/>*** <br/><br/>Liên tiếp những tình tiết gay cấn và hấp dẫn sẽ có trong truyện <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a>, mời bạn đọc khám phá. <br/><br/> '
WHEN `id` = '112' THEN 'Truyện <a href=\"http://webtruyen.com/tro-choi-tu-vong-luan-hoi/\">Trò Chơi Tử Vong Luân Hồi</a> sẽ đưa chúng ta đến những năng lực trong trò chơi mà có thể sẽ áp dụng năng lực đó ra ngoài đời thực. Khi áp dụng những kỹ năng ra đời thực cũng là điều không hề dễ dàng...<br/><br/>Người bạn của Tô Bằng chết ẩn mà khiến hắn đến với một trò chơi kỳ lạ. Công ty thần bí kỳ lạ, đồng nghiệp che giấu bí mật, cái chết kỳ lạ của đồng nghiệp...Tất cả đều khiến cho Tô Bằng cuốn vào trong vòng xoáy.<br/><br/>Gia tộc xua đuổi Tô Bằng bởi những âm mưu trùng trùng điệp điệp. Liệu Tô Bằng sẽ áp dụng kỹ năng trong trò chơi ấy ra sao? Sức mạnh đạt đến cỡ nào?<br/><br/>Với tác phẩm <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> đem lại những tình tiết bất ngờ và thú vị cho bạn đọc. Một trò chơi nguy hiểm xoay vòng dẫn dắt bạn đọc đến với một thế giới với sức mạnh cực đại.<br/><br/>Mời bạn đọc khám phá <a href=\"http://webtruyen.com/\">truyện online</a> và tìm kiếm câu trả lời. <br/><br/> '
WHEN `id` = '113' THEN 'Bạn đang đọc truyện Tiên Quốc Đại Đế của tác giả Quan Kỳ trên trang đọc truyện online. Thiên hạ to lớn, duy ta chính thống! Dùng Thiên triều xu thế quét ngang thiên hạ tiên môn! Một cái cường giả tu \'Đế vương chi Đạo\', hàng lâm thế giới Tiên môn san sát, làm cho một cái người tu hành hèn mọn thế tục Vương triều, từng bước một đi đến cùng các đại đỉnh cấp Tiên môn bình khởi bình tọa. Vương triều pháp tắc là, trong thiên hạ chẳng lẽ vương thổ, suất thổ tân chẳng lẽ vương thần! Thiên hạ chính thống chỉ có một, hết thảy tiên môn, đều là tổ chức phi pháp! '
WHEN `id` = '114' THEN 'Đọc thể loại <a href=\"http://webtruyen.com/huyen-huyen/\">truyện huyền huyễn</a> người đọc không thể không bị hấp dẫn vào thế giới hư ảo của câu chuyện.<br/><br/>Có chút thực có chút giả, ảo tưởng nhưng lại rất thật. Một không gian mênh mang. <br/><br/>Hoa thiên long bệnh hoạn, khuyết tật, một người sinh ra mẹ đã chết trải qua bao bi phẫn của cuộc đời.<br/><br/>Vốn cứ tưởng mọi thứ đều mong manh như vậy nhưng nào ngờ lại có tình yêu...<br/><br/>Anh hùng gởi thân ở chiến trường.<br/><br/>Còn ta gởi thân chốn Thiên Đường.<br/><br/>…<br/><br/>Võ có thể thông thần, ý có thể thông thiên.<br/><br/>Thần ma ngạo thế, chư thiên vô hạn.<br/><br/>Bát cực thần điện, hùng bá vạn năm.<br/><br/>Tam giới song song, nhân thần chi chiến.<br/><br/>Cùng đọc tác phẩm <a href=\"http://webtruyen.com/thien-thanh/\">Thiên Thánh</a> để có thể cảm nhận hết được tứ thơ này nhé !!! '
WHEN `id` = '115' THEN 'Ai là fan của tác giả Trạch Trư hay là đã từng mất ăn mất ngủ với bộ truyện <a href=\"http://webtruyen.com/doc-bo-thien-ha/\">độc bộ thiên hạ</a> thì không thể bỏ qua bộ truyện <a href=\"http://webtruyen.com/de-ton\">Đế Tôn</a> này nhé. Đế tôn là truyện thuộc thể loại tiên hiệp. Truyện mới ra mắt ngày 20-2-2013. Hy vọng sẽ làm hài lọng bạn đọc mê <a href=\"http://webtruyen.com\">truyện</a>.<br/><br/>Võ đạo có thể Thông Thần!<br/><br/>Võ đạo tu luyện đến Thần Luân cảnh giới, liền có thể luyện tựu Thần Thông, siêu phàm thoát tục!<br/><br/>tác giả tác phẩm:<br/><br/>[ tiên hiệp ] đế tôn<br/><br/>[ tiên hiệp ] độc bộ thiên hạ<br/><br/>[ tiên hiệp ] sống lại tây du<br/><br/>[ huyền huyễn ] dã man vương tọa<br/><br/>[ tiên hiệp ]Thủy hử tiên đồ '
WHEN `id` = '116' THEN 'Truyện <a href=\"http://webtruyen.com/tien-hiep/\">tiên hiệp</a> <a href=\"http://webtruyen.com/hop-the-song-tu/\">Hợp Thể Song Tu</a> còn gọi tên khác là Chấp Ma của tác giả Mặc Thủy! Cốt truyện ban đầu có một chút sắc hợp lý, thế giới rộng lớn, nhân vật chính không não tàn, gái gú dám yêu dám hận.<br/><br/>Nhân vật chính là Ninh Phàm bị bạn chí thân phản bội hãm hại, để rồi nhờ cơ duyên mà ngẫu nhiên lấy được song tu đế bảo, từ đó bước trên con đường tu ma thiên hạ vô địch. Linh trang, pháp bảo, đạo quả, tiên vân, thiên sương hàn khí, địa mạch yêu hỏa... xuất hiện liên tục.<br/><br/>Năng lực được khám phá đại đạo âm dương, lấy thiên làm thê, lấy địa làm thiếp , lấy thương sinh làm đỉnh lô. Âm dương đại đạo, hợp thể song tu! Sức mạnh chỉ có thể phát huy khi tất cả đều trong một!<br/><br/>Mời bạn đọc theo dõi <a href=\"http://webtruyen.com/\">truyện online</a>. <br/><br/> '
ELSE `description` END, `number_page` = CASE 
WHEN `id` = '107' THEN '8'
WHEN `id` = '108' THEN '11'
WHEN `id` = '109' THEN '12'
WHEN `id` = '110' THEN '39'
WHEN `id` = '111' THEN '2'
WHEN `id` = '112' THEN '3'
WHEN `id` = '113' THEN '27'
WHEN `id` = '114' THEN '11'
WHEN `id` = '115' THEN '42'
WHEN `id` = '116' THEN '1'
ELSE `number_page` END
WHERE `id` IN('107','108','109','110','111','112','113','114','115','116')
ERROR - 2015-05-19 09:23:24 --> Severity: Compile Error --> Cannot redeclare Crawler::getInfoStories() D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 258
ERROR - 2015-05-19 09:24:24 --> Severity: Compile Error --> Cannot redeclare Crawler::getInfoStories() D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 258
ERROR - 2015-05-19 09:25:46 --> Severity: Compile Error --> Cannot redeclare Crawler::getInfoStories() D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 258
ERROR - 2015-05-19 10:26:24 --> Severity: Error --> Call to a member function find() on null D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 212
ERROR - 2015-05-19 10:26:47 --> Severity: Error --> Call to a member function find() on boolean D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 212
ERROR - 2015-05-19 10:27:04 --> Severity: Error --> Call to a member function find() on boolean D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 212
ERROR - 2015-05-19 10:27:20 --> Severity: Error --> Call to a member function find() on boolean D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 212
ERROR - 2015-05-19 10:30:17 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\xampp\htdocs\truyen_word\application\core\MY_Controller.php 20
ERROR - 2015-05-19 10:31:44 --> Severity: Error --> Call to a member function find() on boolean D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 212
ERROR - 2015-05-19 10:36:03 --> Severity: Notice --> Undefined variable: i D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 236
ERROR - 2015-05-19 10:53:01 --> Severity: Error --> Call to a member function find() on boolean D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 246
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:57 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:53:58 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:00 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:01 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:02 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Undefined index: link D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:04 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22' at line 1 - Invalid query: INSERT INTO `tbl_chapters` (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392) VALUES (Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array)
ERROR - 2015-05-19 10:54:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truyen_word\system\core\Exceptions.php:272) D:\xampp\htdocs\truyen_word\system\core\Common.php 569
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:19 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:21 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:54:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22' at line 1 - Invalid query: INSERT INTO `tbl_chapters` (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392) VALUES (Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array)
ERROR - 2015-05-19 10:54:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truyen_word\system\core\Exceptions.php:272) D:\xampp\htdocs\truyen_word\system\core\Common.php 569
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\system\database\DB_driver.php 1392
ERROR - 2015-05-19 10:55:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22' at line 1 - Invalid query: INSERT INTO `tbl_chapters` (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392) VALUES (Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array)
ERROR - 2015-05-19 10:55:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truyen_word\application\models\webtruyen.php:263) D:\xampp\htdocs\truyen_word\system\core\Common.php 569
ERROR - 2015-05-19 11:00:09 --> Query error: Duplicate entry '3702' for key 'stories_id' - Invalid query: INSERT INTO `tbl_chapters` (`crawler_chapter_id`, `crawler_url`, `stories_id`, `title`) VALUES ('372666','http://webtruyen.com/dai-dao-doc-hanh/thien-dao-sat_372666.html','3702','Thiên Đạo Sát'), ('372667','http://webtruyen.com/dai-dao-doc-hanh/tam-phai-den_372667.html','3702','Tâm Phải Đen'), ('512201','http://webtruyen.com/dai-dao-doc-hanh/tu-do-tu-tai_512201.html','3702','Tự Do Tự Tại'), ('512203','http://webtruyen.com/dai-dao-doc-hanh/than-uy-truyen-thua_512203.html','3702','Thần Uy Truyền Thừa'), ('512205','http://webtruyen.com/dai-dao-doc-hanh/phat-ac_512205.html','3702','Phạt Ác'), ('512207','http://webtruyen.com/dai-dao-doc-hanh/ta-cung-muon-song_512207.html','3702','Ta Cũng Muốn Sống'), ('512208','http://webtruyen.com/dai-dao-doc-hanh/thieu-nien-lac-gia_512208.html','3702','Thiếu Niên Lạc Gia'), ('512210','http://webtruyen.com/dai-dao-doc-hanh/su-huynh-tha-mang_512210.html','3702','Sư Huynh Tha Mạng'), ('512211','http://webtruyen.com/dai-dao-doc-hanh/thien-dia-nhu-lo_512211.html','3702','Thiên Địa Như Lò'), ('512213','http://webtruyen.com/dai-dao-doc-hanh/tinh-thuong_512213.html','3702','Tình Thương'), ('512214','http://webtruyen.com/dai-dao-doc-hanh/ta-muon-tu-tien_512214.html','3702','Ta Muốn Tu Tiên'), ('529234','http://webtruyen.com/dai-dao-doc-hanh/dao-the-thien-than_529234.html','3702','Đạo Thể Thiên Thân'), ('530440','http://webtruyen.com/dai-dao-doc-hanh/tien-duyen-tien-duyen_530440.html','3702','Tiên Duyên! Tiên Duyên!'), ('530890','http://webtruyen.com/dai-dao-doc-hanh/muon-xac-an-than_530890.html','3702','Mượn Xác Ẩn Thân'), ('531313','http://webtruyen.com/dai-dao-doc-hanh/thoat-xac-hoa-buom_531313.html','3702','Thoát Xác Hóa Bướm'), ('532036','http://webtruyen.com/dai-dao-doc-hanh/hoi-quy-trung-tho-phan-nhan-gian_532036.html','3702','Hồi Quy Trung Thổ Phản Nhân Gian! ...'), ('532712','http://webtruyen.com/dai-dao-doc-hanh/linh-diep-that-xao-tu-duong-son_532712.html','3702','Linh Điệp Thất Xảo Tử Dương Sơn! ...'), ('532713','http://webtruyen.com/dai-dao-doc-hanh/khi-nen-ra-tay-lien-ra-tay_532713.html','3702','Khi Nên Ra Tay Liền Ra Tay! ...'), ('532940','http://webtruyen.com/dai-dao-doc-hanh/linh-diep-mon-luc-luu-ten-that_532940.html','3702','Linh Điệp Môn Lục Lưu Tên Thật! ...'), ('532942','http://webtruyen.com/dai-dao-doc-hanh/ba-ngan-ta-dao-truyen-chan-kinh_532942.html','3702','Ba Ngàn Tả Đạo Truyền Chân Kinh! ...'), ('533546','http://webtruyen.com/dai-dao-doc-hanh/nhuoc-van-nhu-nhu-tam-tu-tai_533546.html','3702','Nhược Vấn Như Như Tâm Tự Tại! ...'), ('533547','http://webtruyen.com/dai-dao-doc-hanh/sach-cot-phan-nhuc-thoat-xa-vien_533547.html','3702','Sách Cốt Phân Nhục Thoát Xá Viện! ...'), ('534821','http://webtruyen.com/dai-dao-doc-hanh/tam-nhu-luy-tho-nhap-tien-thai_534821.html','3702','Tâm Như Luy Thổ Nhập Tiên Thai! ...'), ('534822','http://webtruyen.com/dai-dao-doc-hanh/khi-xong-cuu-quan-dap-tien-lo_534822.html','3702','Khí Xông Cửu Quan Đạp Tiên Lộ! ...'), ('536322','http://webtruyen.com/dai-dao-doc-hanh/chan-khi-quan-the-thien-dia-khoan_536322.html','3702','Chân Khí Quán Thể Thiên Địa Khoan! ...'), ('536323','http://webtruyen.com/dai-dao-doc-hanh/nam-tay-lon-la-quy-cu_536323.html','3702','Nắm Tay Lớn Là Quy Củ?'), ('537428','http://webtruyen.com/dai-dao-doc-hanh/kiem-anh-luu-quang-dam-khi-han_537428.html','3702','Kiếm Ảnh Lưu Quang Đảm Khí Hàn! ...'), ('537429','http://webtruyen.com/dai-dao-doc-hanh/duong-lenh-mi-vi-nhap-ngo-than_537429.html','3702','Đương Lệnh Mĩ Vị Nhập Ngô Thần ...'), ('537679','http://webtruyen.com/dai-dao-doc-hanh/huu-du-thi-nhan-thuyet-dong-thien_537679.html','3702','Hưu Dữ Thì Nhân Thuyết Động Thiên! ...'), ('537681','http://webtruyen.com/dai-dao-doc-hanh/truoc-tu-duong-nhai-luyen-chan-khi_537681.html','3702','Trước Tử Dương Nhai Luyện Chân Khí! ...'), ('538451','http://webtruyen.com/dai-dao-doc-hanh/mai-dao-soan-soat-huong-heo-de_538451.html','3702','Mài Đao Soàn Soạt Hướng Heo Dê! ...'), ('538452','http://webtruyen.com/dai-dao-doc-hanh/duong-khi-can-nhu-dao-giai-nguu_538452.html','3702','Dưỡng Khí Cần Như Đao Giải Ngưu! ...'), ('538453','http://webtruyen.com/dai-dao-doc-hanh/vang-sinh-phap-chu-do-pham-tran_538453.html','3702','Vãng Sinh Pháp Chú Độ Phàm Trần! ...'), ('538454','http://webtruyen.com/dai-dao-doc-hanh/mot-bua-com-cam-on-khong-cho-bao_538454.html','3702','Một Bữa Cơm Cảm Ơn Không Chỗ ...'), ('538455','http://webtruyen.com/dai-dao-doc-hanh/trong-sach-deu-co-hoang-kim-oc_538455.html','3702','Trong Sách Đều Có Hoàng Kim Ốc! ...'), ('539657','http://webtruyen.com/dai-dao-doc-hanh/thien-chu-phuong-thi-tim-dao-duyen_539657.html','3702','Thiên Chu Phường Thị Tìm Đạo Duyên ...'), ('539659','http://webtruyen.com/dai-dao-doc-hanh/than-thong-dao-bao-tu-hien_539659.html','3702','Thần Thông Đào Bảo Tự Hiện!'), ('539661','http://webtruyen.com/dai-dao-doc-hanh/linh-te-huu-vung-trung-gian-minh_539661.html','3702','Linh Tê Hữu Vựng Trung Gian Minh! ...'), ('539663','http://webtruyen.com/dai-dao-doc-hanh/chung-nhan-tung-trung-duy-doc-kien_539663.html','3702','Chúng Nhân Tùng Trung Duy Độc Kiến! ...'), ('539664','http://webtruyen.com/dai-dao-doc-hanh/tien-tu-nhuoc-dong-co-duyen-an_539664.html','3702','Tiên Tử Nhược Đồng Cơ Duyên Ẩn! ...'), ('540356','http://webtruyen.com/dai-dao-doc-hanh/tu-du-ngu-cong-ti-vuong-oc_540356.html','3702','Tự Dụ Ngu Công Tỉ Vương Ốc! ...'), ('540357','http://webtruyen.com/dai-dao-doc-hanh/nam-son-thai-thach-tam-bat-hoac_540357.html','3702','Nam Sơn Thải Thạch Tâm Bất Hoặc! ...'), ('540358','http://webtruyen.com/dai-dao-doc-hanh/nhat-thiet-phap-khong-quan-tu-tai_540358.html','3702','Nhất Thiết Pháp Không Quan Tự Tại ...'), ('540359','http://webtruyen.com/dai-dao-doc-hanh/cong-duc-vien-man-linh-thach-du_540359.html','3702','Công Đức Viên Mãn Linh Thạch Đủ! ...'), ('540360','http://webtruyen.com/dai-dao-doc-hanh/chuyen-tot-thanh-doi-toi_540360.html','3702','Chuyện Tốt Thành Đôi Tới!'), ('541920','http://webtruyen.com/dai-dao-doc-hanh/pha-van-lam-lang-nhap-noi-mon_541920.html','3702','Pha Văn Lâm Lang Nhập Nội Môn! ...'), ('541921','http://webtruyen.com/dai-dao-doc-hanh/khong-nghe-loi-chinh-la-choc-danh_541921.html','3702','Không Nghe Lời Chính Là Chọc Đánh! ...'), ('541922','http://webtruyen.com/dai-dao-doc-hanh/tim-su-huynh-cung-bi-danh_541922.html','3702','Tìm Sư Huynh Cũng Bị Đánh'), ('541923','http://webtruyen.com/dai-dao-doc-hanh/thien-duc-phat-uy-thau-sinh-tu_541923.html','3702','Thiện Đức Phát Uy Thấu Sinh Tử ...'), ('541924','http://webtruyen.com/dai-dao-doc-hanh/trong-mong-thay-le-tu-mau_541924.html','3702','Trong Mộng Thấy Lệ Từ Mẫu'), ('542235','http://webtruyen.com/dai-dao-doc-hanh/tren-tu-duong-nhai-quan-thien-dia_542235.html','3702','Trên Tử Dương Nhai Quan Thiên Địa ...'), ('542238','http://webtruyen.com/dai-dao-doc-hanh/hac-long-cui-dau-dai-dao-thanh_542238.html','3702','Hắc Long Cúi Đầu Đại Đạo Thành! ...'), ('542241','http://webtruyen.com/dai-dao-doc-hanh/hac-long-ba-tram-tinh-trong-treo-nhung-lanh-lung_542241.html','3702','Hắc Long Ba Trầm Tĩnh Trong Trẻo ...'), ('542242','http://webtruyen.com/dai-dao-doc-hanh/kim-phong-ngoc-lo-nhat-tuong-phung_542242.html','3702','Kim Phong Ngọc Lộ Nhất Tương Phùng ...'), ('542244','http://webtruyen.com/dai-dao-doc-hanh/sinh-tu-quyet-trong-thien-bien-dong_542244.html','3702','Sinh Tử Quyết Trong Thien Biến Động ...'), ('542900','http://webtruyen.com/dai-dao-doc-hanh/truye-thuyet-truc-co-tram-kim-dan_542900.html','3702','Truyề Thuyết Trúc Cơ Trảm Kim Đan! ...'), ('542901','http://webtruyen.com/dai-dao-doc-hanh/hac-long-phat-uy-doan-hon-ba_542901.html','3702','Hắc Long Phát Uy Đoạn Hồn Ba! ...'), ('542902','http://webtruyen.com/dai-dao-doc-hanh/tu-dau-chi-co-ta-doc-hanh_542902.html','3702','Tử Đấu Chỉ Có Ta Độc Hành ...'), ('542903','http://webtruyen.com/dai-dao-doc-hanh/co-chet-cung-khong-lui-nua-buoc_542903.html','3702','Có Chết Cũng Không Lùi Nửa Bước ...'), ('542904','http://webtruyen.com/dai-dao-doc-hanh/co-duyen-tha-huong-gap-lai_542904.html','3702','Có Duyên Tha Hương Gặp Lại'), ('543557','http://webtruyen.com/dai-dao-doc-hanh/nhi-quy-tam-vu-thap-that-dao_543557.html','3702','Nhị Quỷ Tam Vu Thập Thất Đạo ...'), ('543558','http://webtruyen.com/dai-dao-doc-hanh/dau-chien-thang-phat-phuong-thon-son_543558.html','3702','Đấu Chiến Thắng Phật Phương Thốn Sơn! ...'), ('543559','http://webtruyen.com/dai-dao-doc-hanh/thien-dia-linh-vat-tay-kinh-tuy_543559.html','3702','Thiên Địa Linh Vật Tẩy Kinh Tủy ...'), ('543560','http://webtruyen.com/dai-dao-doc-hanh/dong-phu-thien-cung-o-truoc-mat_543560.html','3702','Đọng Phủ Thiên Cung Ở Trước Mắt! ...'), ('543561','http://webtruyen.com/dai-dao-doc-hanh/quay-dau-mac-cho-la-hong-tran_543561.html','3702','Quay Đầu Mặc Cho Là Hồng Trần ...'), ('544865','http://webtruyen.com/dai-dao-doc-hanh/yeu-han-tinh-cuu-tuyet-sinh-tu_544865.html','3702','Yêu Hận Tình Cừu Tuyệt Sinh Tử! ...'), ('544866','http://webtruyen.com/dai-dao-doc-hanh/minh-nhat-dang-thien-to-chan-tien_544866.html','3702','Minh Nhật Đăng Thiên Tố Chân Tiên ...'), ('544867','http://webtruyen.com/dai-dao-doc-hanh/hiep-lo-tuong-phung-dung-gia-thang_544867.html','3702','Hiệp Lộ Tương Phùng Dũng Giả Thắng ...'), ('544869','http://webtruyen.com/dai-dao-doc-hanh/tu-hai-van-du-co-hang-ban_544869.html','3702','Tứ Hải Vân Du Có Hàng Bán ...'), ('544871','http://webtruyen.com/dai-dao-doc-hanh/co-le-nhieu-nam-se-gap-nhau_544871.html','3702','Có Lẽ Nhiều Năm Sẽ Gặp Nhau ...'), ('545645','http://webtruyen.com/dai-dao-doc-hanh/con-luan-che-nghe-thap-van-van_545645.html','3702','Côn Luân Chế Nghề Thập Vạn Vấn! ...'), ('545648','http://webtruyen.com/dai-dao-doc-hanh/dao-duc-di-phap-than-nghiet-than_545648.html','3702','Đạo Đức Di Pháp Thần Nghiệt Thân! ...'), ('545650','http://webtruyen.com/dai-dao-doc-hanh/bi-truyen-nhap-tam-phong-linh-cam_545650.html','3702','Bí Truyện Nhập Tâm Phong Linh Cấm! ...'), ('545652','http://webtruyen.com/dai-dao-doc-hanh/dai-dao-mo-mit-ta-doc-hanh_545652.html','3702','Đại Đạo Mờ Mịt Ta Độc Hành! ...'), ('545653','http://webtruyen.com/dai-dao-doc-hanh/nhe-nhu-ho-diep-loan-tuy-phong_545653.html','3702','Nhẹ Như Hồ Điệp Loạn Tùy Phong! ...'), ('546686','http://webtruyen.com/dai-dao-doc-hanh/diep-long-phat-uy-tram-tuyet-dao_546686.html','3702','Điệp Long Phát Uy Trảm Tuyết Đạo! ...'), ('546687','http://webtruyen.com/dai-dao-doc-hanh/giao-long-tram-xu-phien-thuong-hai_546687.html','3702','Giao Long Trảm Xử Phiên Thương Hải! ...'), ('546688','http://webtruyen.com/dai-dao-doc-hanh/bao-ho-tru-thi-bat-vien-son_546688.html','3702','Bạo Hổ Trừ Thì Bạt Viễn Sơn! ...'), ('546690','http://webtruyen.com/dai-dao-doc-hanh/nhat-truong-chi-dia-thien-dia-khoan_546690.html','3702','Nhất Trượng Chi Địa Thiên Địa Khoan! ...'), ('546691','http://webtruyen.com/dai-dao-doc-hanh/thanh-thao-lam-an_546691.html','3702','Thành Thạo Làm Ăn!'), ('547205','http://webtruyen.com/dai-dao-doc-hanh/co-van-mot-buoc-nhap-truong-sinh_547205.html','3702','Cơ Vận Một Bước Nhập Trường Sinh ...'), ('547206','http://webtruyen.com/dai-dao-doc-hanh/tiem-tran-trung-lau-sua-ho-lac_547206.html','3702','Tiệm Trần Trung Lâu Sửa Họ Lạc! ...'), ('547207','http://webtruyen.com/dai-dao-doc-hanh/tung-kiem-dap-khong-dao-bau-troi_547207.html','3702','Tung Kiếm Đạp Không Dạo Bầu Trời ...'), ('547208','http://webtruyen.com/dai-dao-doc-hanh/tap-duong-lay-mau-van-thien-chu_547208.html','3702','Tập Dương Lấy Máu Vạn Thiên Chu ...'), ('547209','http://webtruyen.com/dai-dao-doc-hanh/buon-ban-that-tot-cung-khong-du-cau_547209.html','3702','Buôn Bán Thật Tốt Cung Không Đủ ...'), ('547589','http://webtruyen.com/dai-dao-doc-hanh/xep-hang-xep-den-mo-mo-kieu_547589.html','3702','Xếp Hàng Xếp Đến Mỗ Mỗ Kiều ...'), ('547590','http://webtruyen.com/dai-dao-doc-hanh/mot-y-nghi-sai-lech-ca-ngan-van-dam_547590.html','3702','Một Ý Nghĩ Sai Lệch Cả Ngàn ...'), ('547591','http://webtruyen.com/dai-dao-doc-hanh/uyen-chuyen-chu-ti-xao-y-chan_547591.html','3702','Uyển Chuyển Chu Ti Xảo Ý Chân ...'), ('547592','http://webtruyen.com/dai-dao-doc-hanh/danh-vien-cao-hoi-tong-phuong-than_547592.html','3702','Danh Viên Cao Hội Tống Phương Thần ...'), ('547593','http://webtruyen.com/dai-dao-doc-hanh/ngu-tuong-thien-de-ti-thuy-thuat_547593.html','3702','Ngư Tường Thiển Để Tị Thủy Thuật ...'), ('547905','http://webtruyen.com/dai-dao-doc-hanh/hong-nhan-ngay-xua-con-nho-chang_547905.html','3702','Hồng Nhan Ngày Xưa Còn Nhớ Chăng ...'), ('547906','http://webtruyen.com/dai-dao-doc-hanh/linh-diep-phi-thien-li-chung-ngo-bao-phong-vu_547906.html','3702','Linh Điệp Phi Thiên Lí, Chung Ngộ ...'), ('547907','http://webtruyen.com/dai-dao-doc-hanh/khoai-y-an-cuu-duong-tan-hoan_547907.html','3702','Khoái Ý Ân Cừu Đương Tẫn Hoan ...'), ('547908','http://webtruyen.com/dai-dao-doc-hanh/thai-hu-quai-kiem-toan-sinh-sat_547908.html','3702','Thái Hư Quải Kiếm Toàn Sinh Sát ...'), ('547909','http://webtruyen.com/dai-dao-doc-hanh/van-hoa-tung-trung-qua-phien-hiep-bat-triem-than_547909.html','3702','Vạn Hoa Tùng Trung Quá, Phiến Hiệp ...'), ('548702','http://webtruyen.com/dai-dao-doc-hanh/ngan-dam-huyet-chien-dua-linh-diep_548702.html','3702','Ngàn Dặm Huyết Chiến Đưa Linh Điệp ...'), ('548703','http://webtruyen.com/dai-dao-doc-hanh/kim-dan-nhat-lap-dinh-truong-sinh_548703.html','3702','Kim Đan Nhất Lạp Định Trường Sinh! ...'), ('548704','http://webtruyen.com/dai-dao-doc-hanh/cho-huyen-dieu-cua-chung-sinh-lam_548704.html','3702','Chỗ Huyền Diệu Của Chúng Sinh Lâm! ...'), ('548705','http://webtruyen.com/dai-dao-doc-hanh/lay-lai-cong-dao-dau-thien-chu_548705.html','3702','Lấy Lại Công Đạo Đấu Thiên Chu ...'), ('548706','http://webtruyen.com/dai-dao-doc-hanh/cho-moi-bach-ho-mao-nhat-ke_548706.html','3702','Cho Mời Bạch Hổ Mão Nhật Kê! ...')
ERROR - 2015-05-19 11:01:07 --> Query error: Duplicate entry '372666' for key 'crawler_chapter_id' - Invalid query: INSERT INTO `tbl_chapters` (`crawler_chapter_id`, `crawler_url`, `stories_id`, `title`) VALUES ('372666','http://webtruyen.com/dai-dao-doc-hanh/thien-dao-sat_372666.html','3702','Thiên Đạo Sát'), ('372667','http://webtruyen.com/dai-dao-doc-hanh/tam-phai-den_372667.html','3702','Tâm Phải Đen'), ('512201','http://webtruyen.com/dai-dao-doc-hanh/tu-do-tu-tai_512201.html','3702','Tự Do Tự Tại'), ('512203','http://webtruyen.com/dai-dao-doc-hanh/than-uy-truyen-thua_512203.html','3702','Thần Uy Truyền Thừa'), ('512205','http://webtruyen.com/dai-dao-doc-hanh/phat-ac_512205.html','3702','Phạt Ác'), ('512207','http://webtruyen.com/dai-dao-doc-hanh/ta-cung-muon-song_512207.html','3702','Ta Cũng Muốn Sống'), ('512208','http://webtruyen.com/dai-dao-doc-hanh/thieu-nien-lac-gia_512208.html','3702','Thiếu Niên Lạc Gia'), ('512210','http://webtruyen.com/dai-dao-doc-hanh/su-huynh-tha-mang_512210.html','3702','Sư Huynh Tha Mạng'), ('512211','http://webtruyen.com/dai-dao-doc-hanh/thien-dia-nhu-lo_512211.html','3702','Thiên Địa Như Lò'), ('512213','http://webtruyen.com/dai-dao-doc-hanh/tinh-thuong_512213.html','3702','Tình Thương'), ('512214','http://webtruyen.com/dai-dao-doc-hanh/ta-muon-tu-tien_512214.html','3702','Ta Muốn Tu Tiên'), ('529234','http://webtruyen.com/dai-dao-doc-hanh/dao-the-thien-than_529234.html','3702','Đạo Thể Thiên Thân'), ('530440','http://webtruyen.com/dai-dao-doc-hanh/tien-duyen-tien-duyen_530440.html','3702','Tiên Duyên! Tiên Duyên!'), ('530890','http://webtruyen.com/dai-dao-doc-hanh/muon-xac-an-than_530890.html','3702','Mượn Xác Ẩn Thân'), ('531313','http://webtruyen.com/dai-dao-doc-hanh/thoat-xac-hoa-buom_531313.html','3702','Thoát Xác Hóa Bướm'), ('532036','http://webtruyen.com/dai-dao-doc-hanh/hoi-quy-trung-tho-phan-nhan-gian_532036.html','3702','Hồi Quy Trung Thổ Phản Nhân Gian! ...'), ('532712','http://webtruyen.com/dai-dao-doc-hanh/linh-diep-that-xao-tu-duong-son_532712.html','3702','Linh Điệp Thất Xảo Tử Dương Sơn! ...'), ('532713','http://webtruyen.com/dai-dao-doc-hanh/khi-nen-ra-tay-lien-ra-tay_532713.html','3702','Khi Nên Ra Tay Liền Ra Tay! ...'), ('532940','http://webtruyen.com/dai-dao-doc-hanh/linh-diep-mon-luc-luu-ten-that_532940.html','3702','Linh Điệp Môn Lục Lưu Tên Thật! ...'), ('532942','http://webtruyen.com/dai-dao-doc-hanh/ba-ngan-ta-dao-truyen-chan-kinh_532942.html','3702','Ba Ngàn Tả Đạo Truyền Chân Kinh! ...'), ('533546','http://webtruyen.com/dai-dao-doc-hanh/nhuoc-van-nhu-nhu-tam-tu-tai_533546.html','3702','Nhược Vấn Như Như Tâm Tự Tại! ...'), ('533547','http://webtruyen.com/dai-dao-doc-hanh/sach-cot-phan-nhuc-thoat-xa-vien_533547.html','3702','Sách Cốt Phân Nhục Thoát Xá Viện! ...'), ('534821','http://webtruyen.com/dai-dao-doc-hanh/tam-nhu-luy-tho-nhap-tien-thai_534821.html','3702','Tâm Như Luy Thổ Nhập Tiên Thai! ...'), ('534822','http://webtruyen.com/dai-dao-doc-hanh/khi-xong-cuu-quan-dap-tien-lo_534822.html','3702','Khí Xông Cửu Quan Đạp Tiên Lộ! ...'), ('536322','http://webtruyen.com/dai-dao-doc-hanh/chan-khi-quan-the-thien-dia-khoan_536322.html','3702','Chân Khí Quán Thể Thiên Địa Khoan! ...'), ('536323','http://webtruyen.com/dai-dao-doc-hanh/nam-tay-lon-la-quy-cu_536323.html','3702','Nắm Tay Lớn Là Quy Củ?'), ('537428','http://webtruyen.com/dai-dao-doc-hanh/kiem-anh-luu-quang-dam-khi-han_537428.html','3702','Kiếm Ảnh Lưu Quang Đảm Khí Hàn! ...'), ('537429','http://webtruyen.com/dai-dao-doc-hanh/duong-lenh-mi-vi-nhap-ngo-than_537429.html','3702','Đương Lệnh Mĩ Vị Nhập Ngô Thần ...'), ('537679','http://webtruyen.com/dai-dao-doc-hanh/huu-du-thi-nhan-thuyet-dong-thien_537679.html','3702','Hưu Dữ Thì Nhân Thuyết Động Thiên! ...'), ('537681','http://webtruyen.com/dai-dao-doc-hanh/truoc-tu-duong-nhai-luyen-chan-khi_537681.html','3702','Trước Tử Dương Nhai Luyện Chân Khí! ...'), ('538451','http://webtruyen.com/dai-dao-doc-hanh/mai-dao-soan-soat-huong-heo-de_538451.html','3702','Mài Đao Soàn Soạt Hướng Heo Dê! ...'), ('538452','http://webtruyen.com/dai-dao-doc-hanh/duong-khi-can-nhu-dao-giai-nguu_538452.html','3702','Dưỡng Khí Cần Như Đao Giải Ngưu! ...'), ('538453','http://webtruyen.com/dai-dao-doc-hanh/vang-sinh-phap-chu-do-pham-tran_538453.html','3702','Vãng Sinh Pháp Chú Độ Phàm Trần! ...'), ('538454','http://webtruyen.com/dai-dao-doc-hanh/mot-bua-com-cam-on-khong-cho-bao_538454.html','3702','Một Bữa Cơm Cảm Ơn Không Chỗ ...'), ('538455','http://webtruyen.com/dai-dao-doc-hanh/trong-sach-deu-co-hoang-kim-oc_538455.html','3702','Trong Sách Đều Có Hoàng Kim Ốc! ...'), ('539657','http://webtruyen.com/dai-dao-doc-hanh/thien-chu-phuong-thi-tim-dao-duyen_539657.html','3702','Thiên Chu Phường Thị Tìm Đạo Duyên ...'), ('539659','http://webtruyen.com/dai-dao-doc-hanh/than-thong-dao-bao-tu-hien_539659.html','3702','Thần Thông Đào Bảo Tự Hiện!'), ('539661','http://webtruyen.com/dai-dao-doc-hanh/linh-te-huu-vung-trung-gian-minh_539661.html','3702','Linh Tê Hữu Vựng Trung Gian Minh! ...'), ('539663','http://webtruyen.com/dai-dao-doc-hanh/chung-nhan-tung-trung-duy-doc-kien_539663.html','3702','Chúng Nhân Tùng Trung Duy Độc Kiến! ...'), ('539664','http://webtruyen.com/dai-dao-doc-hanh/tien-tu-nhuoc-dong-co-duyen-an_539664.html','3702','Tiên Tử Nhược Đồng Cơ Duyên Ẩn! ...'), ('540356','http://webtruyen.com/dai-dao-doc-hanh/tu-du-ngu-cong-ti-vuong-oc_540356.html','3702','Tự Dụ Ngu Công Tỉ Vương Ốc! ...'), ('540357','http://webtruyen.com/dai-dao-doc-hanh/nam-son-thai-thach-tam-bat-hoac_540357.html','3702','Nam Sơn Thải Thạch Tâm Bất Hoặc! ...'), ('540358','http://webtruyen.com/dai-dao-doc-hanh/nhat-thiet-phap-khong-quan-tu-tai_540358.html','3702','Nhất Thiết Pháp Không Quan Tự Tại ...'), ('540359','http://webtruyen.com/dai-dao-doc-hanh/cong-duc-vien-man-linh-thach-du_540359.html','3702','Công Đức Viên Mãn Linh Thạch Đủ! ...'), ('540360','http://webtruyen.com/dai-dao-doc-hanh/chuyen-tot-thanh-doi-toi_540360.html','3702','Chuyện Tốt Thành Đôi Tới!'), ('541920','http://webtruyen.com/dai-dao-doc-hanh/pha-van-lam-lang-nhap-noi-mon_541920.html','3702','Pha Văn Lâm Lang Nhập Nội Môn! ...'), ('541921','http://webtruyen.com/dai-dao-doc-hanh/khong-nghe-loi-chinh-la-choc-danh_541921.html','3702','Không Nghe Lời Chính Là Chọc Đánh! ...'), ('541922','http://webtruyen.com/dai-dao-doc-hanh/tim-su-huynh-cung-bi-danh_541922.html','3702','Tìm Sư Huynh Cũng Bị Đánh'), ('541923','http://webtruyen.com/dai-dao-doc-hanh/thien-duc-phat-uy-thau-sinh-tu_541923.html','3702','Thiện Đức Phát Uy Thấu Sinh Tử ...'), ('541924','http://webtruyen.com/dai-dao-doc-hanh/trong-mong-thay-le-tu-mau_541924.html','3702','Trong Mộng Thấy Lệ Từ Mẫu'), ('542235','http://webtruyen.com/dai-dao-doc-hanh/tren-tu-duong-nhai-quan-thien-dia_542235.html','3702','Trên Tử Dương Nhai Quan Thiên Địa ...'), ('542238','http://webtruyen.com/dai-dao-doc-hanh/hac-long-cui-dau-dai-dao-thanh_542238.html','3702','Hắc Long Cúi Đầu Đại Đạo Thành! ...'), ('542241','http://webtruyen.com/dai-dao-doc-hanh/hac-long-ba-tram-tinh-trong-treo-nhung-lanh-lung_542241.html','3702','Hắc Long Ba Trầm Tĩnh Trong Trẻo ...'), ('542242','http://webtruyen.com/dai-dao-doc-hanh/kim-phong-ngoc-lo-nhat-tuong-phung_542242.html','3702','Kim Phong Ngọc Lộ Nhất Tương Phùng ...'), ('542244','http://webtruyen.com/dai-dao-doc-hanh/sinh-tu-quyet-trong-thien-bien-dong_542244.html','3702','Sinh Tử Quyết Trong Thien Biến Động ...'), ('542900','http://webtruyen.com/dai-dao-doc-hanh/truye-thuyet-truc-co-tram-kim-dan_542900.html','3702','Truyề Thuyết Trúc Cơ Trảm Kim Đan! ...'), ('542901','http://webtruyen.com/dai-dao-doc-hanh/hac-long-phat-uy-doan-hon-ba_542901.html','3702','Hắc Long Phát Uy Đoạn Hồn Ba! ...'), ('542902','http://webtruyen.com/dai-dao-doc-hanh/tu-dau-chi-co-ta-doc-hanh_542902.html','3702','Tử Đấu Chỉ Có Ta Độc Hành ...'), ('542903','http://webtruyen.com/dai-dao-doc-hanh/co-chet-cung-khong-lui-nua-buoc_542903.html','3702','Có Chết Cũng Không Lùi Nửa Bước ...'), ('542904','http://webtruyen.com/dai-dao-doc-hanh/co-duyen-tha-huong-gap-lai_542904.html','3702','Có Duyên Tha Hương Gặp Lại'), ('543557','http://webtruyen.com/dai-dao-doc-hanh/nhi-quy-tam-vu-thap-that-dao_543557.html','3702','Nhị Quỷ Tam Vu Thập Thất Đạo ...'), ('543558','http://webtruyen.com/dai-dao-doc-hanh/dau-chien-thang-phat-phuong-thon-son_543558.html','3702','Đấu Chiến Thắng Phật Phương Thốn Sơn! ...'), ('543559','http://webtruyen.com/dai-dao-doc-hanh/thien-dia-linh-vat-tay-kinh-tuy_543559.html','3702','Thiên Địa Linh Vật Tẩy Kinh Tủy ...'), ('543560','http://webtruyen.com/dai-dao-doc-hanh/dong-phu-thien-cung-o-truoc-mat_543560.html','3702','Đọng Phủ Thiên Cung Ở Trước Mắt! ...'), ('543561','http://webtruyen.com/dai-dao-doc-hanh/quay-dau-mac-cho-la-hong-tran_543561.html','3702','Quay Đầu Mặc Cho Là Hồng Trần ...'), ('544865','http://webtruyen.com/dai-dao-doc-hanh/yeu-han-tinh-cuu-tuyet-sinh-tu_544865.html','3702','Yêu Hận Tình Cừu Tuyệt Sinh Tử! ...'), ('544866','http://webtruyen.com/dai-dao-doc-hanh/minh-nhat-dang-thien-to-chan-tien_544866.html','3702','Minh Nhật Đăng Thiên Tố Chân Tiên ...'), ('544867','http://webtruyen.com/dai-dao-doc-hanh/hiep-lo-tuong-phung-dung-gia-thang_544867.html','3702','Hiệp Lộ Tương Phùng Dũng Giả Thắng ...'), ('544869','http://webtruyen.com/dai-dao-doc-hanh/tu-hai-van-du-co-hang-ban_544869.html','3702','Tứ Hải Vân Du Có Hàng Bán ...'), ('544871','http://webtruyen.com/dai-dao-doc-hanh/co-le-nhieu-nam-se-gap-nhau_544871.html','3702','Có Lẽ Nhiều Năm Sẽ Gặp Nhau ...'), ('545645','http://webtruyen.com/dai-dao-doc-hanh/con-luan-che-nghe-thap-van-van_545645.html','3702','Côn Luân Chế Nghề Thập Vạn Vấn! ...'), ('545648','http://webtruyen.com/dai-dao-doc-hanh/dao-duc-di-phap-than-nghiet-than_545648.html','3702','Đạo Đức Di Pháp Thần Nghiệt Thân! ...'), ('545650','http://webtruyen.com/dai-dao-doc-hanh/bi-truyen-nhap-tam-phong-linh-cam_545650.html','3702','Bí Truyện Nhập Tâm Phong Linh Cấm! ...'), ('545652','http://webtruyen.com/dai-dao-doc-hanh/dai-dao-mo-mit-ta-doc-hanh_545652.html','3702','Đại Đạo Mờ Mịt Ta Độc Hành! ...'), ('545653','http://webtruyen.com/dai-dao-doc-hanh/nhe-nhu-ho-diep-loan-tuy-phong_545653.html','3702','Nhẹ Như Hồ Điệp Loạn Tùy Phong! ...'), ('546686','http://webtruyen.com/dai-dao-doc-hanh/diep-long-phat-uy-tram-tuyet-dao_546686.html','3702','Điệp Long Phát Uy Trảm Tuyết Đạo! ...'), ('546687','http://webtruyen.com/dai-dao-doc-hanh/giao-long-tram-xu-phien-thuong-hai_546687.html','3702','Giao Long Trảm Xử Phiên Thương Hải! ...'), ('546688','http://webtruyen.com/dai-dao-doc-hanh/bao-ho-tru-thi-bat-vien-son_546688.html','3702','Bạo Hổ Trừ Thì Bạt Viễn Sơn! ...'), ('546690','http://webtruyen.com/dai-dao-doc-hanh/nhat-truong-chi-dia-thien-dia-khoan_546690.html','3702','Nhất Trượng Chi Địa Thiên Địa Khoan! ...'), ('546691','http://webtruyen.com/dai-dao-doc-hanh/thanh-thao-lam-an_546691.html','3702','Thành Thạo Làm Ăn!'), ('547205','http://webtruyen.com/dai-dao-doc-hanh/co-van-mot-buoc-nhap-truong-sinh_547205.html','3702','Cơ Vận Một Bước Nhập Trường Sinh ...'), ('547206','http://webtruyen.com/dai-dao-doc-hanh/tiem-tran-trung-lau-sua-ho-lac_547206.html','3702','Tiệm Trần Trung Lâu Sửa Họ Lạc! ...'), ('547207','http://webtruyen.com/dai-dao-doc-hanh/tung-kiem-dap-khong-dao-bau-troi_547207.html','3702','Tung Kiếm Đạp Không Dạo Bầu Trời ...'), ('547208','http://webtruyen.com/dai-dao-doc-hanh/tap-duong-lay-mau-van-thien-chu_547208.html','3702','Tập Dương Lấy Máu Vạn Thiên Chu ...'), ('547209','http://webtruyen.com/dai-dao-doc-hanh/buon-ban-that-tot-cung-khong-du-cau_547209.html','3702','Buôn Bán Thật Tốt Cung Không Đủ ...'), ('547589','http://webtruyen.com/dai-dao-doc-hanh/xep-hang-xep-den-mo-mo-kieu_547589.html','3702','Xếp Hàng Xếp Đến Mỗ Mỗ Kiều ...'), ('547590','http://webtruyen.com/dai-dao-doc-hanh/mot-y-nghi-sai-lech-ca-ngan-van-dam_547590.html','3702','Một Ý Nghĩ Sai Lệch Cả Ngàn ...'), ('547591','http://webtruyen.com/dai-dao-doc-hanh/uyen-chuyen-chu-ti-xao-y-chan_547591.html','3702','Uyển Chuyển Chu Ti Xảo Ý Chân ...'), ('547592','http://webtruyen.com/dai-dao-doc-hanh/danh-vien-cao-hoi-tong-phuong-than_547592.html','3702','Danh Viên Cao Hội Tống Phương Thần ...'), ('547593','http://webtruyen.com/dai-dao-doc-hanh/ngu-tuong-thien-de-ti-thuy-thuat_547593.html','3702','Ngư Tường Thiển Để Tị Thủy Thuật ...'), ('547905','http://webtruyen.com/dai-dao-doc-hanh/hong-nhan-ngay-xua-con-nho-chang_547905.html','3702','Hồng Nhan Ngày Xưa Còn Nhớ Chăng ...'), ('547906','http://webtruyen.com/dai-dao-doc-hanh/linh-diep-phi-thien-li-chung-ngo-bao-phong-vu_547906.html','3702','Linh Điệp Phi Thiên Lí, Chung Ngộ ...'), ('547907','http://webtruyen.com/dai-dao-doc-hanh/khoai-y-an-cuu-duong-tan-hoan_547907.html','3702','Khoái Ý Ân Cừu Đương Tẫn Hoan ...'), ('547908','http://webtruyen.com/dai-dao-doc-hanh/thai-hu-quai-kiem-toan-sinh-sat_547908.html','3702','Thái Hư Quải Kiếm Toàn Sinh Sát ...'), ('547909','http://webtruyen.com/dai-dao-doc-hanh/van-hoa-tung-trung-qua-phien-hiep-bat-triem-than_547909.html','3702','Vạn Hoa Tùng Trung Quá, Phiến Hiệp ...'), ('548702','http://webtruyen.com/dai-dao-doc-hanh/ngan-dam-huyet-chien-dua-linh-diep_548702.html','3702','Ngàn Dặm Huyết Chiến Đưa Linh Điệp ...'), ('548703','http://webtruyen.com/dai-dao-doc-hanh/kim-dan-nhat-lap-dinh-truong-sinh_548703.html','3702','Kim Đan Nhất Lạp Định Trường Sinh! ...'), ('548704','http://webtruyen.com/dai-dao-doc-hanh/cho-huyen-dieu-cua-chung-sinh-lam_548704.html','3702','Chỗ Huyền Diệu Của Chúng Sinh Lâm! ...'), ('548705','http://webtruyen.com/dai-dao-doc-hanh/lay-lai-cong-dao-dau-thien-chu_548705.html','3702','Lấy Lại Công Đạo Đấu Thiên Chu ...'), ('548706','http://webtruyen.com/dai-dao-doc-hanh/cho-moi-bach-ho-mao-nhat-ke_548706.html','3702','Cho Mời Bạch Hổ Mão Nhật Kê! ...')
