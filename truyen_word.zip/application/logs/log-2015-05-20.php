<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:52 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:53 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:54 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:55 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:56 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:57 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:36:58 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 263
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:30 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:31 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:32 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:33 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:38:34 --> Severity: Notice --> Undefined variable: crawler_stories_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 259
ERROR - 2015-05-20 05:53:14 --> Severity: Notice --> Undefined variable: arr_stories_crawler D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 300
ERROR - 2015-05-20 05:53:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 300
ERROR - 2015-05-20 05:57:52 --> Severity: Notice --> Use of undefined constant crawler_chapter_id - assumed 'crawler_chapter_id' D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 300
ERROR - 2015-05-20 05:57:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 319
ERROR - 2015-05-20 05:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 319
ERROR - 2015-05-20 05:59:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 319
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 255
ERROR - 2015-05-20 06:12:51 --> Query error: Duplicate entry '0' for key 'crawler_chapter_id' - Invalid query: INSERT INTO `tbl_chapters` (`crawler_chapter_id`, `crawler_stories_id`, `crawler_url`, `stories_id`, `title`) VALUES ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 1'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2'), ('','44',NULL,'113','Q. 2')
ERROR - 2015-05-20 06:12:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truyen_word\system\core\Exceptions.php:272) D:\xampp\htdocs\truyen_word\system\core\Common.php 569
ERROR - 2015-05-20 06:26:57 --> Query error: Duplicate entry '0' for key 'crawler_chapter_id' - Invalid query: INSERT INTO `tbl_chapters` (`crawler_chapter_id`, `crawler_stories_id`, `crawler_url`, `stories_id`, `title`) VALUES ('631951','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/xoa-bo-han-gia_631951.html','129','Xóa Bỏ Hàn Gia'), ('631952','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/yeu-con-nhieu-lam-_631952.html','129','Yêu Con Nhiều Lắm !'), ('631953','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/di-du-hoc_631953.html','129','Đi Du Học'), ('631954','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/moi-thu-khong-quen_631954.html','129','Mối Thù Không Quên'), ('631957','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/tro-ve_631957.html','129','Trở Về'), ('','6614',0,'129','\'\'xin Lỗi, Tôi Bận Rồi!\'\''), ('6632803','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/qua-khu-6-nam-truoc_632803.html','129','Quá Khứ 6 Năm Trước'), ('632804','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/ngay-met-moi-se-som-qua-nhanh-_632804.html','129','Ngày Mệt Mỏi Sẽ Sớm Qua Nhanh ...'), ('634867','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/bon-nhan-vat-moi_634867.html','129','Bốn Nhân Vật Mới'), ('634868','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/em-chon-ai-_634868.html','129','Em Chọn Ai !'), ('634869','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/kid-la-ai-_634869.html','129','Kid Là Ai ?'), ('634870','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/sai-bao-kid_634870.html','129','Sai Bảo Kid'), ('635935','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/cong-vien-natural-park_635935.html','129','Công Viên Natural Park'), ('635936','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/cam-giac-la_635936.html','129','Cảm Giác Lạ'), ('637267','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/cuoc-thi-tong-dot_637267.html','129','Cuộc Thi Tổng Dợt'), ('638401','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/ket-qua-bat-ngo_638401.html','129','Kết Quả Bất Ngờ'), ('639326','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/bi-thuong_639326.html','129','Bị Thương'), ('639328','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/su-xuat-hien-cua-han_639328.html','129','Sự Xuất Hiện Của Hắn'), ('640645','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/bua-com-nhu-thuong-le_640645.html','129','Bữa Cơm Như Thường Lệ'), ('642180','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/johbefr_642180.html','129','Johbefr'), ('643081','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/nghe-len_643081.html','129','Nghe Lén'), ('','6614',0,'129','\'\'không Quan Tâm\'\''), ('644291','6614','http://webtruyen.com/ngoc-kha-nhi-em-la-cua-anh/chuan-bi-le-dinh-uoc-1_644291.html','129','Chuẩn Bị Lễ Đính Ước (1)')
ERROR - 2015-05-20 07:02:08 --> Severity: Notice --> Undefined variable: story D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 303
ERROR - 2015-05-20 07:02:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 303
ERROR - 2015-05-20 07:02:08 --> Severity: Notice --> Undefined variable: story D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 303
ERROR - 2015-05-20 07:02:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 303
ERROR - 2015-05-20 07:02:08 --> Severity: Notice --> Undefined variable: story D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 303
ERROR - 2015-05-20 07:02:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 303
ERROR - 2015-05-20 07:02:08 --> Severity: Notice --> Undefined variable: story D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 303
ERROR - 2015-05-20 07:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 303
ERROR - 2015-05-20 07:02:09 --> Severity: Notice --> Undefined variable: story D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 307
ERROR - 2015-05-20 07:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 307
ERROR - 2015-05-20 07:02:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 322
ERROR - 2015-05-20 08:21:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 322
ERROR - 2015-05-20 08:22:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:32:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:33:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:35:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:35:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:36:06 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:36:06 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:36:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:36:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:36:47 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:37:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:37:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:37:41 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:38:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:38:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:38:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:38:54 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:38:54 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:38:54 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:39:17 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:39:17 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:39:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:40:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:40:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:40:45 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:40:54 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:40:54 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:40:54 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:40:54 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:40:54 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:40:54 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:41:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:41:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:41:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:43 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:44 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:44 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 256
ERROR - 2015-05-20 08:42:44 --> Severity: Notice --> Undefined variable: crawler_chapter_id D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 270
ERROR - 2015-05-20 08:42:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:43:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 261
ERROR - 2015-05-20 08:43:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 261
ERROR - 2015-05-20 08:43:08 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:43:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 262
ERROR - 2015-05-20 08:43:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 262
ERROR - 2015-05-20 08:43:24 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:44:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 262
ERROR - 2015-05-20 08:44:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 262
ERROR - 2015-05-20 08:44:30 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:44:54 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 262
ERROR - 2015-05-20 08:44:54 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 262
ERROR - 2015-05-20 08:44:54 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:47:37 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 08:47:37 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 323
ERROR - 2015-05-20 10:17:57 --> 404 Page Not Found: ../modules/admin_tools/controllers//index
ERROR - 2015-05-20 10:21:29 --> Severity: Notice --> Undefined index: arr_data D:\xampp\htdocs\truyen_word\templates_c\cb034831e7f9a23e2fea2fb91f05e42c1634f7b0.file.listconfig.tpl.php 72
ERROR - 2015-05-20 10:21:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\cb034831e7f9a23e2fea2fb91f05e42c1634f7b0.file.listconfig.tpl.php 72
ERROR - 2015-05-20 11:18:51 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\detail.tpl"  on line 236 "</div> <script type="text/javascript">var addthis_config = {"data_track_addressbar":false};</script>"  - Unexpected ":", expected one of: "}" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 233
ERROR - 2015-05-20 11:20:08 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\detail.tpl"  on line 852 "FB.init({appId: '436858599773584', status: true, cookie: true, xfbml: true});"  - Unexpected ": ", expected one of: "}" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 849
ERROR - 2015-05-20 11:21:13 --> 404 Page Not Found: ../modules/stories/controllers/Stories/public
ERROR - 2015-05-20 11:21:13 --> 404 Page Not Found: ../modules/stories/controllers/Stories/public
ERROR - 2015-05-20 11:21:13 --> 404 Page Not Found: ../modules/stories/controllers/Stories/public
ERROR - 2015-05-20 11:21:14 --> 404 Page Not Found: /index
ERROR - 2015-05-20 11:26:52 --> 404 Page Not Found: /index
ERROR - 2015-05-20 11:31:20 --> 404 Page Not Found: /index
ERROR - 2015-05-20 11:33:29 --> 404 Page Not Found: /index
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 198
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 208
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 220
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 303
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 327
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 334
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 341
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 348
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 355
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 421
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 198
ERROR - 2015-05-20 11:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 208
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 220
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 303
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 327
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 334
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 341
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 348
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 355
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 421
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 198
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 208
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 220
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 303
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 327
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 334
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 341
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 348
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 355
ERROR - 2015-05-20 11:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 421
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 198
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 208
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 220
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 303
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 327
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 334
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 341
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 348
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 355
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 421
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 198
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 208
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 220
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 303
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 327
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 334
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 341
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 348
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 355
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 421
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 198
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 208
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 220
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 303
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 327
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 334
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 341
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 348
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 355
ERROR - 2015-05-20 11:40:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 421
ERROR - 2015-05-20 11:40:20 --> 404 Page Not Found: /index
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 198
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 208
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 220
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 303
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 327
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 334
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 341
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 348
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 355
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 421
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 198
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 208
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 220
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 303
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 327
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 334
ERROR - 2015-05-20 11:41:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 341
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 348
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 355
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 421
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 198
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 208
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 220
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 303
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 327
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 334
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 341
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 348
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 355
ERROR - 2015-05-20 11:41:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 421
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-20 11:44:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-20 11:44:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
