<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 04:43:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 04:43:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 04:47:17 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\chapter.tpl"  on line 270 "FB.init({appId: '436858599773584', status: true, cookie: true, xfbml: true});"  - Unexpected ": ", expected one of: "}" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 267
ERROR - 2015-05-21 04:48:13 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\stories\views\chapter.tpl"  on line 335 "var test = $('#report_success').slideDown('fast').delay(1000).slideUp('fast', function(){$('#modal_truyen_report').modal('hide');});"  - Unexpected "(", expected one of: "{" , "identifier" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 332
ERROR - 2015-05-21 04:56:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\63fc7a59a0d4b73b74511d22f4ae27e411b42a09.file.chapter.tpl.php 285
ERROR - 2015-05-21 04:56:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\63fc7a59a0d4b73b74511d22f4ae27e411b42a09.file.chapter.tpl.php 288
ERROR - 2015-05-21 04:56:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\63fc7a59a0d4b73b74511d22f4ae27e411b42a09.file.chapter.tpl.php 285
ERROR - 2015-05-21 04:56:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\63fc7a59a0d4b73b74511d22f4ae27e411b42a09.file.chapter.tpl.php 288
ERROR - 2015-05-21 04:56:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\63fc7a59a0d4b73b74511d22f4ae27e411b42a09.file.chapter.tpl.php 285
ERROR - 2015-05-21 04:56:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\63fc7a59a0d4b73b74511d22f4ae27e411b42a09.file.chapter.tpl.php 288
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:03:04 --> 404 Page Not Found: /index
ERROR - 2015-05-21 05:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:03:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:03:17 --> 404 Page Not Found: /index
ERROR - 2015-05-21 05:05:23 --> 404 Page Not Found: /index
ERROR - 2015-05-21 05:05:25 --> 404 Page Not Found: /index
ERROR - 2015-05-21 05:06:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:06:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:06:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:06:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:06:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:06:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:06:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:06:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:06:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:06:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:06:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:06:46 --> 404 Page Not Found: /index
ERROR - 2015-05-21 05:06:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:06:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:06:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:06:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:06:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:06:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:06:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:06:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:06:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:06:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:09:03 --> 404 Page Not Found: /index
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:09:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:09:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:09:32 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 05:09:32 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 05:09:32 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 05:09:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 05:09:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 05:09:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 05:09:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 05:09:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 05:09:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 05:09:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 05:09:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 05:09:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 05:09:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 05:10:00 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 05:10:00 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 05:10:00 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:32:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 10:32:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 10:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 10:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 10:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 10:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 10:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 10:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 10:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 10:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 10:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 10:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 10:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 10:33:41 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:33:41 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:33:41 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:36:46 --> Severity: Notice --> Undefined variable: key D:\xampp\htdocs\truyen_word\application\modules\stories\controllers\stories.php 59
ERROR - 2015-05-21 10:36:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\modules\stories\controllers\stories.php 60
ERROR - 2015-05-21 10:36:46 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:36:46 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:36:46 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:37:22 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:37:22 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:37:22 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:38:34 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:38:34 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:38:35 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:38:35 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 10:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 10:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 10:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 10:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 10:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 10:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 10:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 10:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 10:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 10:39:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 10:39:35 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:39:35 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:39:35 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 10:52:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:52:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:52:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:52:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:52:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:52:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:52:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:53:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:53:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:53:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:53:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:53:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:53:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:53:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:53:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:53:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:53:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:53:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:55:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:55:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:55:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:55:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:55:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:55:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 291
ERROR - 2015-05-21 10:55:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 10:55:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 292
ERROR - 2015-05-21 11:02:41 --> Severity: Notice --> Undefined variable: r D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 346
ERROR - 2015-05-21 11:03:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 11:03:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 11:03:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 11:03:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 11:03:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 11:03:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 11:03:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 11:03:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 11:03:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 11:03:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 11:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 11:03:23 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:03:23 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:03:23 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:25:05 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:25:05 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:25:05 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:25:05 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 11:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 11:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 11:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 11:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 11:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 11:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 11:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 11:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 11:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 11:25:31 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:25:31 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:25:31 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:25:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 11:25:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 11:25:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 11:25:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 11:25:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 11:25:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 11:25:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 11:25:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 11:25:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 11:25:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 11:25:36 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:25:36 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:25:36 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:25:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 197
ERROR - 2015-05-21 11:25:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 207
ERROR - 2015-05-21 11:25:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 219
ERROR - 2015-05-21 11:25:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 302
ERROR - 2015-05-21 11:25:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 325
ERROR - 2015-05-21 11:25:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 332
ERROR - 2015-05-21 11:25:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 339
ERROR - 2015-05-21 11:25:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 346
ERROR - 2015-05-21 11:25:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 353
ERROR - 2015-05-21 11:25:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\templates_c\c762fe121a6727433db1a9a0ec6eaea4efc9a4fa.file.detail.tpl.php 418
ERROR - 2015-05-21 11:26:56 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:26:56 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
ERROR - 2015-05-21 11:26:56 --> 404 Page Not Found: ../modules/stories/controllers/Stories/dai-dao-doc-hanh
