ERROR - 2015-05-05 10:48:55 --> Severity: Notice --> Undefined property: Auth::$login_manager D:\xampp\htdocs\codeigniter-dev\application\controllers\Auth.php 60
ERROR - 2015-05-05 10:48:55 --> Severity: Error --> Call to a member function process_login() on null D:\xampp\htdocs\codeigniter-dev\application\controllers\Auth.php 60
ERROR - 2015-05-05 10:50:29 --> Severity: Notice --> Undefined property: Auth::$login_manager D:\xampp\htdocs\codeigniter-dev\application\controllers\Auth.php 60
ERROR - 2015-05-05 10:50:29 --> Severity: Error --> Call to a member function process_login() on null D:\xampp\htdocs\codeigniter-dev\application\controllers\Auth.php 60
ERROR - 2015-05-05 10:51:01 --> Severity: Notice --> Undefined property: Auth::$login_manager D:\xampp\htdocs\codeigniter-dev\application\controllers\Auth.php 60
ERROR - 2015-05-05 10:51:01 --> Severity: Error --> Call to a member function process_login() on null D:\xampp\htdocs\codeigniter-dev\application\controllers\Auth.php 60
ERROR - 2015-05-05 16:17:20 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:17:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:17:20 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\codeigniter-dev\application\tests\helpers\Encrypt_helper_test.php 23
ERROR - 2015-05-05 16:17:47 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:17:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:17:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Common.php 573
ERROR - 2015-05-05 16:17:47 --> Severity: Compile Error --> Cannot make non static method PHPUnit_Framework_TestCase::setUp() static in class Encrypt_Helper_Test D:\xampp\htdocs\codeigniter-dev\application\tests\helpers\Encrypt_helper_test.php 4
ERROR - 2015-05-05 16:18:00 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:18:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:18:42 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:18:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 11:20:44 --> Severity: Error --> Call to undefined function encrypt_sha256() D:\xampp\htdocs\codeigniter-dev\application\controllers\Auth.php 59
ERROR - 2015-05-05 11:21:27 --> Severity: Notice --> Undefined property: Auth::$encrypt D:\xampp\htdocs\codeigniter-dev\application\controllers\Auth.php 59
ERROR - 2015-05-05 11:21:27 --> Severity: Error --> Call to a member function encrypt_sha256() on null D:\xampp\htdocs\codeigniter-dev\application\controllers\Auth.php 59
ERROR - 2015-05-05 11:25:58 --> Severity: Error --> Call to undefined function encrypt_sha256() D:\xampp\htdocs\codeigniter-dev\application\controllers\Auth.php 59
ERROR - 2015-05-05 11:26:36 --> Severity: Error --> Call to undefined method Auth::encrypt_sha256() D:\xampp\htdocs\codeigniter-dev\application\controllers\Auth.php 59
ERROR - 2015-05-05 11:29:49 --> 404 Page Not Found: User/index
ERROR - 2015-05-05 11:39:55 --> 404 Page Not Found: User/index
ERROR - 2015-05-05 16:40:15 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:40:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:40:25 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:40:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:40:42 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:40:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:41:20 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:41:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:42:12 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:42:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:42:45 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:42:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:45:06 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:45:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:47:04 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:47:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:48:39 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:48:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:50:36 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:50:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:50:57 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:50:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:51:02 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:51:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:53:11 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:53:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:53:12 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:53:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:53:16 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:53:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:53:17 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:53:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:53:24 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:53:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:53:47 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:53:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 16:53:48 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 16:53:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 11:53:56 --> 404 Page Not Found: User/index
ERROR - 2015-05-05 11:55:19 --> 404 Page Not Found: Product/list
ERROR - 2015-05-05 11:55:23 --> 404 Page Not Found: Product/list
ERROR - 2015-05-05 11:58:56 --> 404 Page Not Found: Product/list
ERROR - 2015-05-05 11:58:58 --> 404 Page Not Found: Product/list
ERROR - 2015-05-05 11:58:59 --> 404 Page Not Found: Product/list
ERROR - 2015-05-05 11:59:14 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(157) : eval()'d code 39
ERROR - 2015-05-05 11:59:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(157) : eval()'d code 39
ERROR - 2015-05-05 12:03:20 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 39
ERROR - 2015-05-05 12:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 39
ERROR - 2015-05-05 12:04:03 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 39
ERROR - 2015-05-05 12:04:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 39
ERROR - 2015-05-05 12:04:11 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 39
ERROR - 2015-05-05 12:04:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 39
ERROR - 2015-05-05 12:05:06 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 39
ERROR - 2015-05-05 12:05:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 39
ERROR - 2015-05-05 12:10:19 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\codeigniter-dev\application\controllers\Product.php 24
ERROR - 2015-05-05 12:10:27 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 41
ERROR - 2015-05-05 12:10:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 41
ERROR - 2015-05-05 12:14:03 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\templates_c\910b0e2a1e3d3492bc74a3fe782156a361fed839.file.list.tpl.php 41
ERROR - 2015-05-05 12:14:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\templates_c\910b0e2a1e3d3492bc74a3fe782156a361fed839.file.list.tpl.php 41
ERROR - 2015-05-05 12:15:09 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\templates_c\910b0e2a1e3d3492bc74a3fe782156a361fed839.file.list.tpl.php 41
ERROR - 2015-05-05 12:15:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\templates_c\910b0e2a1e3d3492bc74a3fe782156a361fed839.file.list.tpl.php 41
ERROR - 2015-05-05 17:17:42 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 17:17:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 17:22:11 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 17:22:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 17:22:25 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 17:22:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 17:24:32 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 17:24:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 12:31:05 --> Severity: Notice --> Undefined property: Product::$Product_dao D:\xampp\htdocs\codeigniter-dev\application\controllers\Product.php 37
ERROR - 2015-05-05 12:31:05 --> Severity: Error --> Call to a member function get() on null D:\xampp\htdocs\codeigniter-dev\application\controllers\Product.php 37
ERROR - 2015-05-05 12:32:14 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\templates_c\910b0e2a1e3d3492bc74a3fe782156a361fed839.file.list.tpl.php 41
ERROR - 2015-05-05 12:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\templates_c\910b0e2a1e3d3492bc74a3fe782156a361fed839.file.list.tpl.php 41
ERROR - 2015-05-05 12:32:43 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\templates_c\910b0e2a1e3d3492bc74a3fe782156a361fed839.file.list.tpl.php 41
ERROR - 2015-05-05 12:32:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\templates_c\910b0e2a1e3d3492bc74a3fe782156a361fed839.file.list.tpl.php 41
ERROR - 2015-05-05 12:32:52 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\templates_c\910b0e2a1e3d3492bc74a3fe782156a361fed839.file.list.tpl.php 41
ERROR - 2015-05-05 12:32:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\templates_c\910b0e2a1e3d3492bc74a3fe782156a361fed839.file.list.tpl.php 41
ERROR - 2015-05-05 12:37:35 --> Severity: Notice --> Undefined index: title D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 41
ERROR - 2015-05-05 12:37:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\codeigniter-dev\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 41
ERROR - 2015-05-05 17:41:25 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 17:41:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 17:43:53 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 17:43:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
ERROR - 2015-05-05 17:50:41 --> Severity: Notice --> Undefined index: REQUEST_METHOD D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 208
ERROR - 2015-05-05 17:50:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\codeigniter-dev\system\core\Exceptions.php:272) D:\xampp\htdocs\codeigniter-dev\system\core\Security.php 277
