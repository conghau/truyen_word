<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-05-14 04:25:43 --> Severity: Error --> Class 'Webtruyen' not found D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\crawler.php 160
ERROR - 2015-05-14 04:28:44 --> Severity: Error --> Call to a member function getElementById() on boolean D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 84
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:34:10 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:35:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:36:36 --> Severity: Error --> Call to a member function children() on array D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 97
ERROR - 2015-05-14 04:47:02 --> Severity: Error --> Call to a member function find() on array D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 96
ERROR - 2015-05-14 04:47:17 --> Severity: Error --> Call to a member function find() on null D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 96
ERROR - 2015-05-14 04:48:43 --> Severity: Error --> Call to undefined function first_child() D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 96
ERROR - 2015-05-14 04:49:48 --> Severity: Error --> Call to a member function find() on array D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 96
ERROR - 2015-05-14 08:30:17 --> Query error: Table 'order.crawler_m_data' doesn't exist - Invalid query: SELECT *
FROM `crawler_m_data`
ERROR - 2015-05-14 08:31:02 --> Query error: Table 'order.crawler_m_data' doesn't exist - Invalid query: SELECT *
FROM `crawler_m_data`
ERROR - 2015-05-14 08:42:12 --> 404 Page Not Found: ../modules/crawler/controllers/Crawler/public
ERROR - 2015-05-14 08:42:12 --> 404 Page Not Found: ../modules/crawler/controllers/Crawler/public
ERROR - 2015-05-14 08:44:11 --> 404 Page Not Found: ../modules/crawler/controllers/Crawler/public
ERROR - 2015-05-14 08:44:11 --> 404 Page Not Found: ../modules/crawler/controllers/Crawler/public
ERROR - 2015-05-14 08:44:11 --> 404 Page Not Found: ../modules/crawler/controllers/Crawler/public
ERROR - 2015-05-14 08:44:31 --> 404 Page Not Found: ../modules/crawler/controllers/Crawler/public
ERROR - 2015-05-14 08:44:31 --> 404 Page Not Found: ../modules/crawler/controllers/Crawler/public
ERROR - 2015-05-14 08:44:31 --> 404 Page Not Found: ../modules/crawler/controllers/Crawler/public
ERROR - 2015-05-14 08:44:43 --> 404 Page Not Found: ../modules/crawler/controllers/Crawler/public
ERROR - 2015-05-14 08:44:43 --> 404 Page Not Found: ../modules/crawler/controllers/Crawler/public
ERROR - 2015-05-14 08:44:43 --> 404 Page Not Found: ../modules/crawler/controllers/Crawler/public
ERROR - 2015-05-14 08:44:54 --> Severity: error --> Exception: Unable to read template file 'master.tpl' D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_resource_file.php 70
ERROR - 2015-05-14 08:56:18 --> Query error: Unknown column 'parent_is' in 'where clause' - Invalid query: SELECT *
FROM `crawler_m_data`
WHERE `parent_is` = ''
ERROR - 2015-05-14 08:59:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '''' at line 3 - Invalid query: SELECT *
FROM `crawler_m_data`
WHERE `parent_id` is null ''
ERROR - 2015-05-14 09:01:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '''' at line 3 - Invalid query: SELECT *
FROM `crawler_m_data`
WHERE `parent_id` is null ''
ERROR - 2015-05-14 09:01:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '''' at line 3 - Invalid query: SELECT *
FROM `crawler_m_data`
WHERE `parent_id` is null ''
ERROR - 2015-05-14 09:06:25 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\manager.php 16
ERROR - 2015-05-14 09:06:25 --> Severity: Warning --> get_object_vars() expects parameter 1 to be object, null given D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\manager.php 16
ERROR - 2015-05-14 09:06:35 --> Severity: Warning --> get_object_vars() expects parameter 1 to be object, array given D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\manager.php 16
ERROR - 2015-05-14 09:08:10 --> Severity: Error --> Call to a member function find() on boolean D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 89
ERROR - 2015-05-14 09:22:35 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\manager.php 24
ERROR - 2015-05-14 09:22:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\manager.php:22) D:\xampp\htdocs\truyen_word\system\core\Common.php 569
ERROR - 2015-05-14 09:22:43 --> Severity: Error --> Call to undefined method stdClass::value() D:\xampp\htdocs\truyen_word\application\modules\crawler\controllers\manager.php 22
ERROR - 2015-05-14 09:39:11 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\crawler\views\listconfig.tpl"  on line 12 "<div class="panel-heading">{$config['url'}</div>"  - Unexpected "}" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 5
ERROR - 2015-05-14 09:39:22 --> Severity: Notice --> Undefined index: url D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 77
ERROR - 2015-05-14 09:39:22 --> Severity: Notice --> Undefined index: url D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 77
ERROR - 2015-05-14 09:39:59 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 79
ERROR - 2015-05-14 09:39:59 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatebase.php(171) : eval()'d code 79
ERROR - 2015-05-14 09:40:31 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\templates_c\f3e8af82038f8165d6ecc7791769747f3aa644b2.file.listconfig.tpl.php 79
ERROR - 2015-05-14 09:40:31 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\templates_c\f3e8af82038f8165d6ecc7791769747f3aa644b2.file.listconfig.tpl.php 79
ERROR - 2015-05-14 09:40:43 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\templates_c\f3e8af82038f8165d6ecc7791769747f3aa644b2.file.listconfig.tpl.php 79
ERROR - 2015-05-14 09:40:43 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\truyen_word\templates_c\f3e8af82038f8165d6ecc7791769747f3aa644b2.file.listconfig.tpl.php 79
ERROR - 2015-05-14 10:02:14 --> Severity: error --> Exception: Syntax error in template "D:\xampp\htdocs\truyen_word\application\modules\crawler\views\listconfig.tpl"  on line 25 "{$count = 1;}"  - Unexpected ";", expected one of: "}" D:\xampp\htdocs\truyen_word\application\third_party\Smarty\sysplugins\smarty_internal_templatecompilerbase.php 17
ERROR - 2015-05-14 10:38:36 --> 404 Page Not Found: ../modules/crawler/controllers/Manager/getInfoStoriesWebTruyen
ERROR - 2015-05-14 10:43:07 --> Severity: Error --> Call to undefined function url_friendly() D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 144
ERROR - 2015-05-14 10:43:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truyen_word\application\models\webtruyen.php:143) D:\xampp\htdocs\truyen_word\system\core\Common.php 569
ERROR - 2015-05-14 10:43:54 --> Severity: Error --> Call to undefined function url_friendly() D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 144
ERROR - 2015-05-14 11:12:20 --> Severity: Notice --> Undefined variable: arr_intro D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 158
ERROR - 2015-05-14 11:13:02 --> Severity: Notice --> Undefined variable: arr_intro D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 156
ERROR - 2015-05-14 11:24:47 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 170
ERROR - 2015-05-14 11:46:52 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) D:\xampp\htdocs\truyen_word\application\models\webtruyen.php 198
