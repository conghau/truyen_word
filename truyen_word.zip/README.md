*----- How to run project -------*
Require : PHP >5.5

------
+ create new db name : order
+ import order.sql
+ Edit connection in \application\config\database.php if NEED

+ Login to web : hieu/hieu


